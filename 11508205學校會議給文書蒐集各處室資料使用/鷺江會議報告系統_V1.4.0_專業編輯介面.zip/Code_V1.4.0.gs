/**
 * 鷺江國小主任組長會議報告彙整系統 V1.4.0
 * 基本設定與共用工具
 *
 * V1.3.0 效能版重點（行為與 V1.2.1 完全相同，只改快與慢）：
 *  1. Script Properties 一次讀取，取代每次 RPC 的多趟往返。
 *  2. Units / Settings 跨請求快取，寫入時以資料版本號即時失效。
 *  3. AuditLog 改為緩衝後一次寫入。
 *  4. 產檔的大字串替換由 O(n²) 改成單次線性拼接。
 *  5. 頁首／內文日期替換由三趟掃描合併為一趟。
 *  6. 正文圖片改用 UrlFetchApp.fetchAll() 平行預取（產檔最大加速點）。
 *  7. Relationships 累積後一次寫回；zip 省去重複 copyBlob。
 *  8. 新增 getBootstrapLite / prefetchMyReports 供前端「先出畫面再補資料」。
 *
 * V1.4.0：前端導入多事項導覽／焦點編輯；後端沿用 V1.3.1 Word 交付門檻機制。
 *  小檔維持直接傳回瀏覽器（最快）；超過門檻自動改寫入 Drive 並回傳下載連結，
 *  避免 base64 傳輸成為新的瓶頸。模式與門檻可在「系統設定」調整。
 */
const APP = Object.freeze({
  NAME: '鷺江國小主任組長會議報告彙整系統',
  VERSION: '1.4.0',
  SCHEMA_VERSION: 4,
  AUTH_TOKEN_DAYS: 7,
  TIMEZONE: 'Asia/Taipei',
  ROOT_FOLDER_NAME: '鷺江國小_主任組長會議報告彙整系統',
  DB_NAME: '鷺江國小_主任組長會議報告彙整系統_DB',
  MAX_REPORT_JSON_CHARS: 42000,
  MAX_UPLOAD_BYTES: 10 * 1024 * 1024,
  INLINE_IMAGE_MAX_BYTES: 8 * 1024 * 1024,
  DEFAULT_IMAGE_WIDTH_CM: 13.5,
  TRIGGER_HANDLER: 'deadlineSweep',
  DOCX_MIME: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ZIP_MIME: 'application/zip',

  // V1.3.1 Word 交付門檻
  // 小檔直接經 google.script.run 傳回瀏覽器最快（省掉一次 Drive 寫入）；
  // 但 base64 會膨脹約 33%，檔案一大，這條傳輸管道本身就會變成瓶頸，
  // 因此超過門檻改寫入 Drive 並回傳下載連結。
  OUTPUT_FOLDER_NAME: '會議輸出',
  WORD_INLINE_MAX_BYTES: 4 * 1024 * 1024,        // 預設門檻 4 MB
  WORD_INLINE_HARD_MAX_BYTES: 18 * 1024 * 1024,  // 硬上限：即使設定強制直傳也不會超過
  WORD_OUTPUT_KEEP: 3                            // 每場會議在 Drive 保留最近幾份輸出
});

const PROP = Object.freeze({
  DB_ID: 'LJ_MEETING_DB_ID',
  ROOT_FOLDER_ID: 'LJ_MEETING_ROOT_FOLDER_ID',
  AUTH_SECRET: 'LJ_MEETING_AUTH_SECRET',
  SCHEMA_VERSION: 'LJ_MEETING_SCHEMA_VERSION',
  ROOT_FOLDER_URL: 'LJ_MEETING_ROOT_FOLDER_URL'
});

const SHEET = Object.freeze({
  USERS: 'Users',
  MEETINGS: 'Meetings',
  REPORTS: 'Reports',
  REPORT_HISTORY: 'ReportHistory',
  ATTACHMENTS: 'Attachments',
  AUDIT: 'AuditLog',
  SETTINGS: 'Settings',
  UNITS: 'Units'
});

const HEADERS = Object.freeze({
  Users: ['email','name','role','unitIds','active','createdAt','updatedAt','passwordSalt','passwordHash','mustChangePassword','lastLoginAt','directorOffice'],
  Meetings: ['meetingId','name','meetingDate','schoolYear','semester','deadlineLocal','templateFileId','status','autoDeliver','notifyEmail','outputWordFileId','outputPdfFileId','reminder24Sent','reminder2Sent','deliveredAt','createdBy','createdAt','updatedAt','trashState','trashedAt','trashedBy','trashPreviousStatus','unitSnapshotJson'],
  Reports: ['reportId','meetingId','unitId','ownerEmail','status','contentJson','revision','updatedBy','updatedAt','submittedAt','noReport'],
  ReportHistory: ['historyId','reportId','meetingId','unitId','revision','status','contentJson','changedBy','changedAt'],
  Attachments: ['attachmentId','meetingId','unitId','reportId','fileId','fileName','mimeType','sizeBytes','fileUrl','inlineImage','pixelWidth','pixelHeight','uploadedBy','uploadedAt','active'],
  AuditLog: ['auditId','eventType','entityType','entityId','meetingId','unitId','actorEmail','detailJson','createdAt'],
  Settings: ['key','value','updatedBy','updatedAt'],
  Units: ['unitId','office','label','color','sortOrder','active','createdAt','updatedAt']
});

/**
 * Google Sheets 會把看似日期的字串自動轉成 Date。
 * Web App 又不能直接回傳 Date，因此所有日期欄位統一以純文字保存，
 * 並在讀取時容忍既有 Date 值，自動正規化。
 */
const DATE_FIELD_TYPES = Object.freeze({
  Users: Object.freeze({createdAt:'datetime', updatedAt:'datetime', lastLoginAt:'datetime'}),
  Meetings: Object.freeze({meetingDate:'date', deadlineLocal:'datetime', deliveredAt:'datetime', createdAt:'datetime', updatedAt:'datetime', trashedAt:'datetime'}),
  Reports: Object.freeze({updatedAt:'datetime', submittedAt:'datetime'}),
  ReportHistory: Object.freeze({changedAt:'datetime'}),
  Attachments: Object.freeze({uploadedAt:'datetime'}),
  AuditLog: Object.freeze({createdAt:'datetime'}),
  Settings: Object.freeze({updatedAt:'datetime'}),
  Units: Object.freeze({createdAt:'datetime', updatedAt:'datetime'})
});

/**
 * 依附件中現有 Word 版型建立的單位清單。
 * label 必須與 Word 左側欄位文字對得上；比對時會自動忽略空白與換行。
 */
const DEFAULT_UNIT_DEFS = Object.freeze([
  {id:'TEACHING', office:'教務處', label:'教學組', color:'#FFF7B2', order:10},
  {id:'INFO', office:'教務處', label:'資訊組', color:'#FFF7B2', order:20},
  {id:'CURRICULUM', office:'教務處', label:'課程組', color:'#FFF7B2', order:30},
  {id:'REGISTRATION', office:'教務處', label:'註冊組', color:'#FFF7B2', order:40},
  {id:'BILINGUAL', office:'教務處', label:'雙語組', color:'#FFF7B2', order:50},
  {id:'ACADEMIC_DIRECTOR', office:'教務處', label:'教務主任', color:'#FFF7B2', order:60},

  {id:'PE', office:'學務處', label:'體育組', color:'#D9EEF6', order:110},
  {id:'DISCIPLINE', office:'學務處', label:'生教組', color:'#D9EEF6', order:120},
  {id:'HEALTH', office:'學務處', label:'衛生組', color:'#D9EEF6', order:130},
  {id:'ACTIVITIES', office:'學務處', label:'訓育組', color:'#D9EEF6', order:140},
  {id:'HEALTH_CENTER', office:'學務處', label:'健康中心', color:'#D9EEF6', order:150},
  {id:'STUDENT_AFFAIRS_DIRECTOR', office:'學務處', label:'學務主任', color:'#D9EEF6', order:160},

  {id:'GENERAL_AFFAIRS', office:'總務處', label:'事務組', color:'#DFEBC8', order:210},
  {id:'CASHIER', office:'總務處', label:'出納組', color:'#DFEBC8', order:220},
  {id:'DOCUMENTS', office:'總務處', label:'文書組', color:'#DFEBC8', order:230},
  {id:'CLERK', office:'總務處', label:'幹事', color:'#DFEBC8', order:240},
  {id:'GENERAL_AFFAIRS_DIRECTOR', office:'總務處', label:'總務主任', color:'#DFEBC8', order:250},

  {id:'COUNSELING', office:'輔導室', label:'輔導組', color:'#F7E5D8', order:310},
  {id:'SPECIAL_ED', office:'輔導室', label:'特教組', color:'#F7E5D8', order:320},
  {id:'SOCIAL_SERVICE', office:'輔導室', label:'社服組', color:'#F7E5D8', order:330},
  {id:'COUNSELING_DIRECTOR', office:'輔導室', label:'輔導主任', color:'#F7E5D8', order:340},

  {id:'HR_DIRECTOR', office:'人事室', label:'人事主任', color:'#E8F0D9', order:410}
]);

const UNIT_SETTINGS_CACHE_ = {all:null, active:null};

function invalidateUnitSettingsCache_() {
  UNIT_SETTINGS_CACHE_.all = null;
  UNIT_SETTINGS_CACHE_.active = null;
  invalidateSheetCache_(SHEET.UNITS);
  bumpDataVersion_();
}

function normalizeUnitSetting_(u) {
  if (!u) return null;
  const sortOrder = Number(u.sortOrder !== undefined ? u.sortOrder : u.order || 0) || 0;
  const active = !(String(u.active).toUpperCase() === 'FALSE' || u.active === false);
  return {
    id:String(u.unitId !== undefined ? u.unitId : u.id || ''),
    unitId:String(u.unitId !== undefined ? u.unitId : u.id || ''),
    office:String(u.office || '').trim(),
    label:String(u.label || '').trim(),
    color:/^#[0-9A-F]{6}$/i.test(String(u.color || '')) ? String(u.color).toUpperCase() : '#E9EEF5',
    order:sortOrder,
    sortOrder,
    active,
    createdAt:String(u.createdAt || ''),
    updatedAt:String(u.updatedAt || '')
  };
}

function defaultUnits_() {
  return DEFAULT_UNIT_DEFS.map(u => normalizeUnitSetting_({
    unitId:u.id, office:u.office, label:u.label, color:u.color, sortOrder:u.order, active:true
  }));
}

function getUnitsInternal_(includeInactive) {
  const key = includeInactive ? 'all' : 'active';
  if (UNIT_SETTINGS_CACHE_[key]) return UNIT_SETTINGS_CACHE_[key].map(x => Object.assign({}, x));

  // V1.3.0：Units 一天只會被管理員改幾次，卻被每一次 RPC 讀取。
  // 跨請求快取 6 小時，任何寫入都會透過 bumpDataVersion_ 讓 key 失效。
  const warm = readSmallSheetCache_(SHEET.UNITS);
  if (warm) {
    const cached = warm.map(normalizeUnitSetting_).filter(u => u && u.id && u.label && u.office);
    if (cached.length) {
      UNIT_SETTINGS_CACHE_.all = cached.map(x => Object.assign({}, x));
      UNIT_SETTINGS_CACHE_.active = cached.filter(u => u.active).map(x => Object.assign({}, x));
      return UNIT_SETTINGS_CACHE_[key].map(x => Object.assign({}, x));
    }
  }

  let rows = [];
  try { rows = getAllObjects_(SHEET.UNITS); } catch (err) { rows = []; }
  let units = rows.map(normalizeUnitSetting_).filter(u => u && u.id && u.label && u.office);
  if (!units.length) units = defaultUnits_();
  units.sort((a,b) => (a.sortOrder - b.sortOrder) || a.office.localeCompare(b.office,'zh-Hant') || a.label.localeCompare(b.label,'zh-Hant'));
  writeSmallSheetCache_(SHEET.UNITS, units);
  UNIT_SETTINGS_CACHE_.all = units.map(x => Object.assign({}, x));
  UNIT_SETTINGS_CACHE_.active = units.filter(u => u.active).map(x => Object.assign({}, x));
  return UNIT_SETTINGS_CACHE_[key].map(x => Object.assign({}, x));
}

function activeUnits_() { return getUnitsInternal_(false); }
function allUnits_() { return getUnitsInternal_(true); }

function directorOffices_() {
  return [...new Set(activeUnits_().map(u => u.office).filter(Boolean))];
}

function officeUnitIds_(office) {
  const name = String(office || '').trim();
  return activeUnits_().filter(u => u.office === name).map(u => u.id);
}

function inferDirectorOffice_(unitIds) {
  const ids = Array.isArray(unitIds)
    ? unitIds.map(String)
    : String(unitIds || '').split(',').map(x => x.trim()).filter(Boolean);
  if (!ids.length) return '';
  const map = Object.fromEntries(allUnits_().map(u => [u.id, u.office]));
  const offices = [...new Set(ids.map(id => map[id]).filter(Boolean))];
  return offices.length === 1 ? offices[0] : '';
}

function snapshotUnitsJson_(units) {
  return JSON.stringify((units || []).map(u => ({
    id:String(u.id || u.unitId || ''), office:String(u.office || ''), label:String(u.label || ''),
    color:String(u.color || '#E9EEF5'), order:Number(u.order !== undefined ? u.order : u.sortOrder || 0)
  })));
}

function parseUnitSnapshot_(json) {
  const raw = safeJsonParse_(json, []);
  if (!Array.isArray(raw) || !raw.length) return [];
  return raw.map(x => normalizeUnitSetting_({
    unitId:x.id || x.unitId, office:x.office, label:x.label, color:x.color,
    sortOrder:x.order !== undefined ? x.order : x.sortOrder, active:true
  })).filter(u => u && u.id && u.office && u.label)
    .sort((a,b) => (a.sortOrder - b.sortOrder) || a.label.localeCompare(b.label,'zh-Hant'));
}

function getMeetingUnits_(meeting) {
  if (!meeting) return activeUnits_();
  const snapshot = parseUnitSnapshot_(meeting.unitSnapshotJson);
  return snapshot.length ? snapshot : activeUnits_();
}

function getMeetingUnitDef_(meeting, unitId) {
  const unit = getMeetingUnits_(meeting).find(u => u.id === String(unitId || ''));
  if (!unit) throw new Error('此會議沒有這個單位：' + unitId);
  return unit;
}

const ALLOWED_UPLOAD_MIME = Object.freeze([
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'image/jpeg',
  'image/png'
]);

function getUnitDef_(unitId) {
  const unit = allUnits_().find(u => u.id === String(unitId || ''));
  if (!unit) throw new Error('找不到單位設定：' + unitId);
  return unit;
}

function getUnitByLabel_(label, unitList) {
  const n = normalizeUnitLabel_(label);
  if (!n) return null;
  const units = Array.isArray(unitList) ? unitList : allUnits_();
  const exact = units.find(u => normalizeUnitLabel_(u.label) === n);
  if (exact) return exact;
  const contains = units
    .filter(u => n.indexOf(normalizeUnitLabel_(u.label)) >= 0)
    .sort((a, b) => b.label.length - a.label.length);
  return contains[0] || null;
}

function normalizeUnitLabel_(s) {
  return String(s || '').replace(/[\s\u00A0\u3000]+/g, '');
}

function uuid_() {
  return Utilities.getUuid();
}

function now_() {
  return new Date();
}

function nowLocalString_() {
  return Utilities.formatDate(now_(), APP.TIMEZONE, "yyyy-MM-dd'T'HH:mm:ss");
}

function isValidDateObject_(v) {
  return Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v.getTime());
}

function parseLocalDateTime_(value) {
  if (value === null || value === undefined || value === '') return null;
  if (isValidDateObject_(value)) return new Date(value.getTime());

  let s = String(value).trim();
  // 支援 HTML datetime-local 的 yyyy-MM-ddTHH:mm 或 yyyy-MM-ddTHH:mm:ss。
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (m) {
    const canonical = `${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6] || '00'}`;
    let d;
    try {
      d = Utilities.parseDate(canonical, APP.TIMEZONE, "yyyy-MM-dd'T'HH:mm:ss");
    } catch (err) {
      throw new Error('日期時間格式錯誤：' + s);
    }
    // 避免 2/30、25:70 之類被解析器寬鬆修正。
    if (Utilities.formatDate(d, APP.TIMEZONE, "yyyy-MM-dd'T'HH:mm:ss") !== canonical) {
      throw new Error('日期時間不存在或格式錯誤：' + s);
    }
    return d;
  }

  // 相容舊版已被 Google Sheets 轉成 Date 後再 String() 的資料。
  const legacy = new Date(s);
  if (!isNaN(legacy.getTime())) return legacy;
  throw new Error('日期時間格式錯誤：' + s);
}

function normalizeLocalDateTimeValue_(value) {
  if (value === null || value === undefined || value === '') return '';
  const d = parseLocalDateTime_(value);
  return Utilities.formatDate(d, APP.TIMEZONE, "yyyy-MM-dd'T'HH:mm:ss");
}

function parseDateOnly_(value) {
  if (value === null || value === undefined || value === '') throw new Error('日期不可空白。');
  if (isValidDateObject_(value)) return new Date(value.getTime());

  let s = String(value).trim().replace(/\//g, '-');
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m) {
    const canonical = `${m[1]}-${m[2]}-${m[3]}`;
    let d;
    try {
      d = Utilities.parseDate(canonical + ' 12:00:00', APP.TIMEZONE, 'yyyy-MM-dd HH:mm:ss');
    } catch (err) {
      throw new Error('日期格式錯誤：' + s);
    }
    if (Utilities.formatDate(d, APP.TIMEZONE, 'yyyy-MM-dd') !== canonical) {
      throw new Error('日期不存在或格式錯誤：' + s);
    }
    return d;
  }

  const legacy = new Date(s);
  if (!isNaN(legacy.getTime())) return legacy;
  throw new Error('日期格式錯誤：' + s);
}

function normalizeDateOnlyValue_(value) {
  return Utilities.formatDate(parseDateOnly_(value), APP.TIMEZONE, 'yyyy-MM-dd');
}

function normalizeSheetDateField_(sheetName, fieldName, value) {
  const type = DATE_FIELD_TYPES[sheetName] && DATE_FIELD_TYPES[sheetName][fieldName];
  if (!type || value === '' || value === null || value === undefined) return value;
  try {
    return type === 'date' ? normalizeDateOnlyValue_(value) : normalizeLocalDateTimeValue_(value);
  } catch (err) {
    // 資料庫若被人工填入不合法內容，不在底層靜默改值；保留原值讓上層顯示明確錯誤。
    return String(value);
  }
}

function deriveSchoolYearSemester_(meetingDate) {
  const d = typeof meetingDate === 'string' ? parseDateOnly_(meetingDate) : meetingDate;
  const y = Number(Utilities.formatDate(d, APP.TIMEZONE, 'yyyy'));
  const m = Number(Utilities.formatDate(d, APP.TIMEZONE, 'M'));
  return {
    schoolYear: m >= 8 ? y - 1911 : y - 1912,
    semester: (m >= 8 || m === 1) ? 1 : 2
  };
}

function formatRocDate_(meetingDate, style) {
  const d = typeof meetingDate === 'string' ? parseDateOnly_(meetingDate) : meetingDate;
  const y = Number(Utilities.formatDate(d, APP.TIMEZONE, 'yyyy')) - 1911;
  const m = Number(Utilities.formatDate(d, APP.TIMEZONE, 'M'));
  const day = Number(Utilities.formatDate(d, APP.TIMEZONE, 'd'));
  if (style === 'dot') return `${y}.${m}.${day}`;
  if (style === 'slash') return `${y}/${m}/${day}`;
  return `${y}年${m}月${day}日`;
}

function meetingDisplayTitle_(meeting) {
  return `${formatRocDate_(meeting.meetingDate, 'zh')}主任組長會議`;
}

function isMeetingLocked_(meeting) {
  if (!meeting) return true;
  if (String(meeting.status) === 'CLOSED') return true;
  const deadline = parseLocalDateTime_(meeting.deadlineLocal);
  return deadline ? now_().getTime() >= deadline.getTime() : false;
}

function extractDriveId_(value) {
  const s = String(value || '').trim();
  if (!s) return '';
  const patterns = [
    /\/d\/([a-zA-Z0-9_-]{20,})/,
    /[?&]id=([a-zA-Z0-9_-]{20,})/,
    /^([a-zA-Z0-9_-]{20,})$/
  ];
  for (const p of patterns) {
    const m = s.match(p);
    if (m) return m[1];
  }
  throw new Error('無法辨識 Google Drive 檔案 ID，請貼上檔案網址或檔案 ID。');
}

function safeJsonParse_(s, fallback) {
  try { return JSON.parse(String(s || '')); } catch (err) { return fallback; }
}

function sanitizeFileName_(name) {
  return String(name || 'file')
    .replace(/[\\/:*?"<>|\x00-\x1F]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 160) || 'file';
}

function isSafeUrl_(url) {
  return /^(https?:\/\/|mailto:)/i.test(String(url || '').trim());
}

function assertSafeUrl_(url) {
  if (!isSafeUrl_(url)) throw new Error('連結只允許 http://、https:// 或 mailto:');
  return String(url).trim();
}

function chineseNumber_(n) {
  const nums = ['零','一','二','三','四','五','六','七','八','九','十'];
  n = Number(n);
  if (n <= 10) return nums[n] || String(n);
  if (n < 20) return '十' + nums[n - 10];
  if (n < 100) {
    const t = Math.floor(n / 10), o = n % 10;
    return nums[t] + '十' + (o ? nums[o] : '');
  }
  return String(n);
}

/**
 * V1.0.8 固定會議報告標號：
 *   第一層：一、
 *   第二層：(一)
 *   第三層：1、
 *   第四層：(1)
 *
 * 使用者可在草稿自行輸入任何一種層級標號；儲存與產檔時會依實際順序重新編號。
 * Section 卡片本身就是第一層，因此 body 內若誤輸入「三、」也會自動校正為第二層。
 */
function parseOutlineLine_(line) {
  let s = String(line === undefined ? '' : line).replace(/\u3000/g, ' ').trim();
  if (!s) return null;
  let m;

  m = s.match(/^[（(]\s*(\d+)\s*[）)]\s*[、.．]?\s*(.*)$/);
  if (m) return {level:4, text:String(m[2] || '').trim()};

  m = s.match(/^[（(]\s*([零〇一二三四五六七八九十百兩]+)\s*[）)]\s*[、.．]?\s*(.*)$/);
  if (m) return {level:2, text:String(m[2] || '').trim()};

  m = s.match(/^(\d+)\s*[、.．]\s*(.*)$/);
  if (m) return {level:3, text:String(m[2] || '').trim()};

  m = s.match(/^([零〇一二三四五六七八九十百兩]+)\s*、\s*(.*)$/);
  if (m) return {level:1, text:String(m[2] || '').trim()};

  return {level:0, text:s};
}

function outlinePrefix_(level, n) {
  level = Number(level || 2);
  n = Math.max(1, Number(n || 1));
  if (level === 1) return `${chineseNumber_(n)}、`;
  if (level === 2) return `(${chineseNumber_(n)})`;
  if (level === 3) return `${n}、`;
  return `(${n})`;
}

function cleanSectionTitle_(value) {
  let s = String(value || '').trim();
  const parsed = parseOutlineLine_(s);
  if (parsed && parsed.level) s = parsed.text;
  s = s.replace(/^【\s*/, '').replace(/\s*】$/, '').trim();
  return s;
}

/**
 * 將 section body 解析成 2～4 層綱要。
 * 沒有標號的每一個非空白段落，預設視為第二層，舊資料也會自動補 (一)(二)…。
 */
function outlineItemsFromBody_(text) {
  const rawLines = String(text || '').replace(/\r/g, '').split('\n').map(s => s.trim()).filter(Boolean);
  const counters = {2:0, 3:0, 4:0};
  const items = [];

  rawLines.forEach(raw => {
    const parsed = parseOutlineLine_(raw) || {level:0, text:raw};
    let level = Number(parsed.level || 0);
    if (level === 1 || level < 2 || level > 4) level = 2;

    counters[level] += 1;
    if (level === 2) { counters[3] = 0; counters[4] = 0; }
    else if (level === 3) { counters[4] = 0; }

    items.push({
      level,
      number:counters[level],
      prefix:outlinePrefix_(level, counters[level]),
      text:String(parsed.text || '').trim(),
      unnumbered:false
    });
  });

  // V1.2.1：標題下若只有一段第二層敘述，不顯示「(一)」。
  // 一旦有第二段或更深層子項，仍維持正式的 (一)(二)→1、→(1) 結構。
  if (items.length === 1 && items[0].level === 2) {
    items[0].prefix = '';
    items[0].unnumbered = true;
  }
  return items;
}

function normalizeSectionBody_(text) {
  return outlineItemsFromBody_(text)
    .map(item => `${item.prefix}${item.text || ''}`)
    .join('\n');
}

/**
 * 四層行政文件凸排。V1.2.1 固定採「緊接標號」版：
 *
 *   一、【標題】
 *      (一)恭賀！本校參加……
 *          1、內文……
 *            (1)內文……
 *
 * 規則：
 * - (一) 後面不插空白、不插 Tab，文字直接緊接。
 * - 第三層「1、」標號起點 = 第二層正文起點。
 * - 第四層只比第三層標號再右移一小格。
 * - hanging 控制換行，第二行會自動回到該層正文起點。
 */
function outlineIndentForLevel_(baseTwips, level) {
  const base = Math.max(360, Math.min(600, Math.round(Number(baseTwips || 480))));

  // 12pt 下的近似字寬：ASCII 括號約半個全形字；「(一)」整體約等於 2 個全形字。
  const level2Label = Math.max(90, Math.round(base * 0.25));     // 480 → 120
  const level2Marker = base;                                   // 480
  const level2Text = level2Label + level2Marker;                // 600

  // 1、 從第二層正文首字的位置開始。
  const level3Label = level2Text;                               // 600
  const level3Marker = Math.max(300, Math.round(base * 0.75));  // 360
  const level3Text = level3Label + level3Marker;                // 960

  // (1) 只再往右一小格。
  const level4Label = level3Label + Math.max(90, Math.round(base * 0.25)); // 720
  const level4Marker = base;                                    // 480
  const level4Text = level4Label + level4Marker;                 // 1200

  const starts = {
    1:{label:0,           text:base,       left:base,       hanging:base},
    2:{label:level2Label, text:level2Text, left:level2Text, hanging:level2Marker},
    3:{label:level3Label, text:level3Text, left:level3Text, hanging:level3Marker},
    4:{label:level4Label, text:level4Text, left:level4Text, hanging:level4Marker}
  };
  return starts[Number(level || 1)] || starts[1];
}

function outlineParagraphPPr_(ppr, baseTwips, level) {
  const ind = outlineIndentForLevel_(baseTwips, level);
  return setParagraphIndent_(stripNumberingFromPPr_(ppr), ind.left, ind.hanging);
}

/** 標號與文字直接相接，不插入空白或 Tab。 */
function outlineBodyParagraphXml_(prefix, text, ppr, baseTwips, level) {
  // 單一敘述沒有標號時，直接對齊第二層正文起點，不保留凸排標號槽。
  if (!String(prefix || '')) {
    const ind = outlineIndentForLevel_(baseTwips, level);
    const plainPPr = setParagraphIndent_(stripNumberingFromPPr_(ppr), ind.text, 0);
    return paragraphXml_(text || '', plainPPr, {});
  }
  const finalPPr = outlineParagraphPPr_(ppr, baseTwips, level);
  return paragraphXml_(`${prefix}${text || ''}`, finalPPr, {});
}
/** Database.gs - Google Sheet 資料層 */

function isSystemSetup_() {
  return !!prop_(PROP.DB_ID);
}

/**
 * V1.0.5：同一次 RPC 執行內重用 Spreadsheet / Sheet / RootFolder handle。
 * SpreadsheetApp.openById() 與 getSheetByName() 都有遠端服務成本，
 * 舊版每一個資料存取 helper 都會重新開啟一次。
 */
let DB_HANDLE_ = null;
let ROOT_FOLDER_HANDLE_ = null;
const SHEET_HANDLE_CACHE_ = {};

/**
 * V1.3.0 效能：Script Properties 一次抓完整包。
 * 舊版每次 RPC 會分別呼叫 getProperty()（isSystemSetup_、ensureSchema_、
 * getAuthSecret_、getDb_、getRootFolderUrlCached_…），每一次都是一趟遠端往返。
 */
let SCRIPT_PROPS_CACHE_ = null;

function props_() {
  if (!SCRIPT_PROPS_CACHE_) {
    SCRIPT_PROPS_CACHE_ = PropertiesService.getScriptProperties().getProperties() || {};
  }
  return SCRIPT_PROPS_CACHE_;
}

function prop_(key) {
  const v = props_()[key];
  return v === undefined ? null : v;
}

function setProps_(map) {
  const clean = {};
  Object.keys(map || {}).forEach(k => clean[k] = String(map[k] === undefined ? '' : map[k]));
  PropertiesService.getScriptProperties().setProperties(clean);
  const c = props_();
  Object.keys(clean).forEach(k => c[k] = clean[k]);
}

function setProp_(key, value) {
  setProps_({[key]: value});
}

function getDb_() {
  if (DB_HANDLE_) return DB_HANDLE_;
  const id = prop_(PROP.DB_ID);
  if (!id) throw new Error('系統尚未初始化。');
  DB_HANDLE_ = SpreadsheetApp.openById(id);
  return DB_HANDLE_;
}

function getRootFolder_() {
  if (ROOT_FOLDER_HANDLE_) return ROOT_FOLDER_HANDLE_;
  const id = prop_(PROP.ROOT_FOLDER_ID);
  if (!id) throw new Error('系統尚未初始化資料夾。');
  ROOT_FOLDER_HANDLE_ = DriveApp.getFolderById(id);
  return ROOT_FOLDER_HANDLE_;
}

function getSheet_(name) {
  if (SHEET_HANDLE_CACHE_[name]) return SHEET_HANDLE_CACHE_[name];
  const sh = getDb_().getSheetByName(name);
  if (!sh) throw new Error('資料工作表不存在：' + name);
  SHEET_HANDLE_CACHE_[name] = sh;
  return sh;
}

function setupSystem(payload) {
  if (isSystemSetup_()) {
    return {ok:true, alreadySetup:true, dbId:prop_(PROP.DB_ID)};
  }
  payload = payload || {};
  const ownerEmail = String(payload.adminEmail || '').toLowerCase().trim();
  const adminPassword = String(payload.adminPassword || '');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(ownerEmail)) throw new Error('請輸入正確的管理員 Email。');
  assertPasswordStrength_(adminPassword);

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    if (isSystemSetup_()) return {ok:true, alreadySetup:true};

    const root = DriveApp.createFolder(APP.ROOT_FOLDER_NAME);
    const uploadFolder = root.createFolder('使用者附件');
    root.createFolder('會議輸出');
    root.createFolder('Word母版');

    const ss = SpreadsheetApp.create(APP.DB_NAME);
    const ssFile = DriveApp.getFileById(ss.getId());
    ssFile.moveTo(root);

    setProps_({
      [PROP.DB_ID]: ss.getId(),
      [PROP.ROOT_FOLDER_ID]: root.getId(),
      [PROP.SCHEMA_VERSION]: String(APP.SCHEMA_VERSION)
    });

    getAuthSecret_();

    // 建立資料表
    const first = ss.getSheets()[0];
    first.setName(SHEET.USERS);
    Object.keys(HEADERS).forEach(name => {
      let sh = ss.getSheetByName(name);
      if (!sh) sh = ss.insertSheet(name);
      initializeSheet_(sh, HEADERS[name]);
    });

    // 單位設定改為資料表管理；第一次建立系統時先寫入既有正式組別。
    seedDefaultUnitsIfEmpty_();

    // 第一位管理員
    appendObject_(SHEET.USERS, {
      email: ownerEmail,
      name: '系統管理員',
      role: 'ADMIN',
      unitIds: activeUnits_().map(u => u.id).join(','),
      active: true,
      createdAt: nowLocalString_(),
      updatedAt: nowLocalString_(),
      passwordSalt: createSalt_(),
      passwordHash: '',
      mustChangePassword: false,
      lastLoginAt: '',
      directorOffice: ''
    });
    const adminRow = findOne_(SHEET.USERS, r => String(r.email).toLowerCase() === ownerEmail);
    updateObjectRow_(SHEET.USERS, adminRow._row, {
      passwordHash: hashPassword_(adminPassword, adminRow.passwordSalt),
      updatedAt: nowLocalString_()
    });

    // 系統設定
    const defaults = {
      SYSTEM_NAME: APP.NAME,
      DEFAULT_TEMPLATE_FILE_ID: '',
      ATTACHMENT_FOLDER_ID: uploadFolder.getId(),
      ALLOWED_EMAIL_DOMAIN: '',
      REMINDER_24H: 'TRUE',
      REMINDER_2H: 'TRUE',
      WORD_DELIVERY_MODE: 'AUTO',
      WORD_INLINE_MAX_MB: '4',
      WORD_DRIVE_SHARING: 'VIEWER'
    };
    Object.keys(defaults).forEach(k => setSettingInternal_(k, defaults[k], ownerEmail));

    // 安裝 15 分鐘掃描排程
    installSystemTriggersInternal_();
    audit_('SYSTEM_SETUP', 'SYSTEM', 'V1', '', '', ownerEmail, {dbId:ss.getId(), rootFolderId:root.getId()});

    return {
      ok:true,
      ownerEmail,
      dbId:ss.getId(),
      rootFolderId:root.getId(),
      rootFolderUrl:root.getUrl()
    };
  } finally {
    lock.releaseLock();
  }
}

function initializeSheet_(sh, headers) {
  sh.clear();
  sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  sh.setFrozenRows(1);
  sh.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#E9EEF5');
  const sheetName = sh.getName();
  if (DATE_FIELD_TYPES[sheetName]) applyDateColumnTextFormats_(sh, sheetName);
  sh.autoResizeColumns(1, headers.length);
}

function sheetHeaders_(sheetName) {
  const h = HEADERS[sheetName];
  if (!h) throw new Error('未定義資料表欄位：' + sheetName);
  return h;
}


function getAllObjects_(sheetName) {
  // V1.0.4：單次執行內的資料表快取，避免同一個請求重複整表讀取。
  if (SHEET_CACHE_[sheetName]) return SHEET_CACHE_[sheetName].slice();
  const sh = getSheet_(sheetName);
  const headers = sheetHeaders_(sheetName);
  const lastRow = sh.getLastRow();
  if (lastRow < 2) {
    SHEET_CACHE_[sheetName] = [];
    return [];
  }
  const values = sh.getRange(2, 1, lastRow - 1, headers.length).getValues();
  const objs = values.map((row, idx) => rowToObject_(sheetName, headers, row, idx + 2));
  SHEET_CACHE_[sheetName] = objs;
  return objs.slice();
}

function rowToObject_(sheetName, headers, row, rowNumber) {
  const obj = {_row: rowNumber};
  headers.forEach((h, i) => obj[h] = normalizeSheetDateField_(sheetName, h, row[i]));
  return obj;
}

function prepareRowForStorage_(sheetName, headers, row) {
  return row.map((value, i) => normalizeSheetDateField_(sheetName, headers[i], value));
}

function applyDateColumnTextFormats_(sh, sheetName, rowNumber) {
  const fields = DATE_FIELD_TYPES[sheetName] || {};
  const headers = sheetHeaders_(sheetName);
  Object.keys(fields).forEach(field => {
    const col = headers.indexOf(field) + 1;
    if (col > 0) sh.getRange(rowNumber || 2, col, rowNumber ? 1 : Math.max(1, sh.getMaxRows() - 1), 1).setNumberFormat('@');
  });
}


function appendObject_(sheetName, obj) {
  const sh = getSheet_(sheetName);
  const headers = sheetHeaders_(sheetName);
  const row = prepareRowForStorage_(sheetName, headers, headers.map(h => obj[h] !== undefined ? obj[h] : ''));
  const targetRow = Math.max(2, sh.getLastRow() + 1);
  // 日期欄在初始化 / migration 時已整欄設為純文字，不再每次新增都 setNumberFormat()。
  sh.getRange(targetRow, 1, 1, headers.length).setValues([row]);
  invalidateSheetCache_(sheetName);
  return targetRow;
}


function updateObjectRow_(sheetName, rowNumber, patch) {
  const sh = getSheet_(sheetName);
  const headers = sheetHeaders_(sheetName);

  // 本次 RPC 若已讀過整張表，直接使用記憶體中的 row，避免更新前再多一次 getValues()。
  const cachedRows = SHEET_CACHE_[sheetName];
  const cached = cachedRows && cachedRows.find(r => Number(r._row) === Number(rowNumber));
  const current = cached
    ? headers.map(h => cached[h])
    : sh.getRange(rowNumber, 1, 1, headers.length).getValues()[0]
        .map((v, i) => normalizeSheetDateField_(sheetName, headers[i], v));

  headers.forEach((h, i) => {
    if (Object.prototype.hasOwnProperty.call(patch, h)) current[i] = patch[h];
  });
  const stored = prepareRowForStorage_(sheetName, headers, current);
  sh.getRange(rowNumber, 1, 1, headers.length).setValues([stored]);
  invalidateSheetCache_(sheetName);
}

function findOne_(sheetName, predicate) {
  const rows = getAllObjects_(sheetName);
  return rows.find(predicate) || null;
}

function findMany_(sheetName, predicate) {
  return getAllObjects_(sheetName).filter(predicate);
}

/**
 * V1.2.1 長期效能層：高成長資料表不要再為了找單一會議而整張讀取 contentJson。
 * 先只讀一個索引欄位，再只抓命中的完整資料列。
 * 5 年後 Reports / ReportHistory 很大時，Dashboard、編輯器與 Word 產檔仍維持穩定。
 */
const TARGET_QUERY_CACHE_ = {};

function fieldColumn_(sheetName, field) {
  const col = sheetHeaders_(sheetName).indexOf(String(field)) + 1;
  if (col <= 0) throw new Error(`資料表 ${sheetName} 找不到欄位：${field}`);
  return col;
}

function rowGroups_(rows) {
  const sorted = [...new Set((rows || []).map(Number).filter(n => n >= 2))].sort((a,b)=>a-b);
  const groups = [];
  sorted.forEach(row => {
    const last = groups[groups.length - 1];
    if (last && last.start + last.count === row) last.count++;
    else groups.push({start:row, count:1});
  });
  return groups;
}

function readObjectRows_(sheetName, rowNumbers) {
  const rows = [];
  const sh = getSheet_(sheetName);
  const headers = sheetHeaders_(sheetName);
  rowGroups_(rowNumbers).forEach(g => {
    const values = sh.getRange(g.start, 1, g.count, headers.length).getValues();
    values.forEach((row, idx) => rows.push(rowToObject_(sheetName, headers, row, g.start + idx)));
  });
  return rows;
}

function getObjectsByFieldValues_(sheetName, field, values) {
  const wanted = [...new Set((Array.isArray(values) ? values : [values]).map(v => String(v)))];
  if (!wanted.length) return [];
  const cacheKey = `${sheetName}|${field}|${wanted.slice().sort().join('\u001f')}`;
  if (TARGET_QUERY_CACHE_[cacheKey]) return TARGET_QUERY_CACHE_[cacheKey].slice();

  const sh = getSheet_(sheetName);
  const lastRow = sh.getLastRow();
  if (lastRow < 2) { TARGET_QUERY_CACHE_[cacheKey] = []; return []; }
  const col = fieldColumn_(sheetName, field);
  const wantedSet = new Set(wanted);
  const keys = sh.getRange(2, col, lastRow - 1, 1).getValues();
  const rowNumbers = [];
  keys.forEach((r, i) => { if (wantedSet.has(String(r[0]))) rowNumbers.push(i + 2); });
  const objects = readObjectRows_(sheetName, rowNumbers);
  TARGET_QUERY_CACHE_[cacheKey] = objects;
  return objects.slice();
}

function getObjectsByFieldValue_(sheetName, field, value) {
  return getObjectsByFieldValues_(sheetName, field, [value]);
}

function getMeetingReports_(meetingId) {
  return getObjectsByFieldValue_(SHEET.REPORTS, 'meetingId', String(meetingId));
}

function findReport_(meetingId, unitId) {
  return getMeetingReports_(meetingId).find(r => String(r.unitId) === String(unitId)) || null;
}

function getMeetingAttachments_(meetingId) {
  return getObjectsByFieldValue_(SHEET.ATTACHMENTS, 'meetingId', String(meetingId));
}

function deleteRowsByFieldValue_(sheetName, field, value) {
  const sh = getSheet_(sheetName);
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return 0;
  const col = fieldColumn_(sheetName, field);
  const keys = sh.getRange(2, col, lastRow - 1, 1).getValues();
  const rowNumbers = [];
  keys.forEach((r, i) => { if (String(r[0]) === String(value)) rowNumbers.push(i + 2); });
  const groups = rowGroups_(rowNumbers).sort((a,b)=>b.start-a.start);
  groups.forEach(g => sh.deleteRows(g.start, g.count));
  if (rowNumbers.length) invalidateSheetCache_(sheetName);
  return rowNumbers.length;
}


function getSetting_(key, fallback) {
  const map = getSettingsMap_();
  const k = String(key);
  if (Object.prototype.hasOwnProperty.call(map, k)) return map[k];
  return fallback === undefined ? '' : fallback;
}

function setSettingInternal_(key, value, actorEmail) {
  const row = findOne_(SHEET.SETTINGS, r => String(r.key) === String(key));
  const data = {key:String(key), value:String(value === undefined ? '' : value), updatedBy:actorEmail || '', updatedAt:nowLocalString_()};
  if (row) updateObjectRow_(SHEET.SETTINGS, row._row, data);
  else appendObject_(SHEET.SETTINGS, data);
  SETTINGS_MAP_CACHE_ = null;
  bumpDataVersion_();
}


function getSafeSettings_() {
  const map = getSettingsMap_();
  return {
    systemName: map.SYSTEM_NAME || APP.NAME,
    defaultTemplateFileId: map.DEFAULT_TEMPLATE_FILE_ID || '',
    allowedEmailDomain: map.ALLOWED_EMAIL_DOMAIN || '',
    wordDeliveryMode: normalizeWordDeliveryMode_(map.WORD_DELIVERY_MODE),
    wordInlineMaxMb: normalizeWordInlineMaxMb_(map.WORD_INLINE_MAX_MB),
    wordDriveSharing: normalizeWordSharing_(map.WORD_DRIVE_SHARING),
    rootFolderUrl: getRootFolderUrlCached_()
  };
}

/**
 * V1.3.0：稽核紀錄改為「先進緩衝、RPC 結束一次寫入」。
 * AuditLog 從來不會在同一次請求內被讀回，因此延後寫入沒有副作用，
 * 但每次儲存／送出／上傳都可以少掉一次 Sheets 寫入往返。
 */
const AUDIT_BUFFER_ = [];

function audit_(eventType, entityType, entityId, meetingId, unitId, actorEmail, detail) {
  try {
    AUDIT_BUFFER_.push({
      auditId: uuid_(),
      eventType: eventType || '',
      entityType: entityType || '',
      entityId: entityId || '',
      meetingId: meetingId || '',
      unitId: unitId || '',
      actorEmail: actorEmail || '',
      detailJson: JSON.stringify(detail || {}),
      createdAt: nowLocalString_()
    });
  } catch (err) {
    console.error('audit buffer failed', err);
  }
}

function flushAuditBuffer_() {
  if (!AUDIT_BUFFER_.length) return;
  const items = AUDIT_BUFFER_.splice(0, AUDIT_BUFFER_.length);
  try {
    const sh = getSheet_(SHEET.AUDIT);
    const headers = sheetHeaders_(SHEET.AUDIT);
    const rows = items.map(o => prepareRowForStorage_(SHEET.AUDIT, headers, headers.map(h => o[h] !== undefined ? o[h] : '')));
    const targetRow = Math.max(2, sh.getLastRow() + 1);
    sh.getRange(targetRow, 1, rows.length, headers.length).setValues(rows);
    invalidateSheetCache_(SHEET.AUDIT);
  } catch (err) {
    console.error('audit flush failed', err);
  }
}

function getOrCreateChildFolder_(parent, name) {
  const it = parent.getFoldersByName(name);
  if (it.hasNext()) return it.next();
  return parent.createFolder(name);
}

function getAttachmentFolder_(meetingId) {
  const idKey = 'ATT_FOLDER_V105_' + String(meetingId || '');
  const cache = CacheService.getScriptCache();
  const cachedId = cache.get(idKey);
  if (cachedId) {
    try { return DriveApp.getFolderById(cachedId); } catch (err) { cache.remove(idKey); }
  }

  const baseId = getSetting_('ATTACHMENT_FOLDER_ID', '');
  const base = baseId ? DriveApp.getFolderById(baseId) : getOrCreateChildFolder_(getRootFolder_(), '使用者附件');
  const folder = getOrCreateChildFolder_(base, String(meetingId));
  cache.put(idKey, folder.getId(), 21600);
  return folder;
}
/** AuthService.gs - 權限 */
let REQUEST_USER_ = null;

function requireUser_() {
  if (!REQUEST_USER_) throw new Error('登入狀態已失效，請重新登入。');
  const user = Object.assign({}, REQUEST_USER_);
  user.role = String(user.role || 'EDITOR').toUpperCase();
  user.unitIdsArray = String(user.unitIds || '').split(',').map(x => x.trim()).filter(Boolean);
  return user;
}

function requireAdmin_() {
  const user = requireUser_();
  if (user.role !== 'ADMIN') throw new Error('此功能僅限系統管理員。');
  return user;
}

function userCanEditUnit_(user, unitId, unitDef) {
  if (!user) return false;
  const role = String(user.role || '').toUpperCase();
  if (role === 'ADMIN') return true;
  const unit = unitDef || getUnitDef_(unitId);
  if (role === 'DIRECTOR') {
    const office = String(user.directorOffice || inferDirectorOffice_(user.unitIdsArray || user.unitIds || '')).trim();
    return !!office && String(unit.office || '') === office;
  }
  const arr = user.unitIdsArray || String(user.unitIds || '').split(',').map(x => x.trim()).filter(Boolean);
  return arr.includes(String(unitId));
}

function assertUnitPermission_(user, unitId, unitDef) {
  const unit = unitDef || getUnitDef_(unitId);
  if (!userCanEditUnit_(user, unitId, unit)) throw new Error('您沒有此單位的編輯權限。');
  return unit;
}

function safeUser_(u) {
  const unitIds = (u.unitIdsArray || String(u.unitIds || '').split(',').filter(Boolean));
  const role = String(u.role || 'EDITOR').toUpperCase();
  return {
    email:String(u.email || ''),
    name:String(u.name || ''),
    role,
    unitIds,
    directorOffice: role === 'DIRECTOR' ? String(u.directorOffice || inferDirectorOffice_(unitIds)) : '',
    mustChangePassword:String(u.mustChangePassword).toUpperCase() === 'TRUE' || u.mustChangePassword === true
  };
}

function listUsers() {
  requireAdmin_();
  return getAllObjects_(SHEET.USERS).map(r => {
    const unitIds = String(r.unitIds || '').split(',').filter(Boolean);
    const role = String(r.role || 'EDITOR').toUpperCase();
    return {
      email:String(r.email || ''), name:String(r.name || ''), role,
      unitIds, directorOffice:role === 'DIRECTOR' ? String(r.directorOffice || inferDirectorOffice_(unitIds)) : '',
      active:String(r.active).toUpperCase() !== 'FALSE',
      mustChangePassword:String(r.mustChangePassword).toUpperCase() === 'TRUE' || r.mustChangePassword === true,
      createdAt:String(r.createdAt || ''), updatedAt:String(r.updatedAt || ''), lastLoginAt:String(r.lastLoginAt || '')
    };
  }).sort((a,b) => a.email.localeCompare(b.email));
}

function emailMatchesAllowedDomain_(email) {
  const allowed = String(getSetting_('ALLOWED_EMAIL_DOMAIN', '') || '').toLowerCase().trim().replace(/^@/, '');
  if (!allowed) return true;
  const domain = String(email || '').toLowerCase().split('@')[1] || '';
  return domain === allowed || domain.endsWith('.' + allowed);
}

function assertEmailAllowed_(email) {
  if (!emailMatchesAllowedDomain_(email)) {
    throw new Error('此 Email 不在系統允許的登入網域內。');
  }
}

function saveUser(payload) {
  const admin = requireAdmin_();
  payload = payload || {};
  const email = String(payload.email || '').toLowerCase().trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Email 格式不正確。');
  assertEmailAllowed_(email);
  const role = String(payload.role || 'EDITOR').toUpperCase();
  if (!['ADMIN','DIRECTOR','EDITOR'].includes(role)) throw new Error('角色錯誤。');

  let unitIds = Array.isArray(payload.unitIds) ? payload.unitIds.map(String) : [];
  if (role === 'DIRECTOR') {
    const directorOffice = String(payload.directorOffice || '').trim();
    if (!directorOffices_().includes(directorOffice)) throw new Error('請選擇有效的主任所屬處室。');
    unitIds = officeUnitIds_(directorOffice);
  }
  unitIds.forEach(getUnitDef_);
  if (role === 'EDITOR' && !unitIds.length) throw new Error('組別編輯者至少要指定一個單位。');

  const row = findOne_(SHEET.USERS, r => String(r.email).toLowerCase() === email);
  const newPassword = String(payload.newPassword || '');
  if (!row && !newPassword) throw new Error('新增帳號時請設定至少 8 碼的初始密碼。');
  if (newPassword) assertPasswordStrength_(newPassword);
  const newActive = payload.active !== false;
  if (row && String(row.role).toUpperCase() === 'ADMIN' && String(row.active).toUpperCase() !== 'FALSE' &&
      (role !== 'ADMIN' || !newActive)) {
    const otherAdmins = getAllObjects_(SHEET.USERS).filter(u =>
      u._row !== row._row &&
      String(u.role).toUpperCase() === 'ADMIN' &&
      String(u.active).toUpperCase() !== 'FALSE'
    );
    if (!otherAdmins.length) throw new Error('至少必須保留一個啟用中的系統管理員。');
  }

  const data = {
    email,
    name:String(payload.name || '').trim(),
    role,
    unitIds:unitIds.join(','),
    active:newActive,
    directorOffice:role === 'DIRECTOR' ? String(payload.directorOffice || '').trim() : '',
    updatedAt:nowLocalString_()
  };
  if (newPassword) {
    const salt = createSalt_();
    data.passwordSalt = salt;
    data.passwordHash = hashPassword_(newPassword, salt);
    data.mustChangePassword = payload.mustChangePassword !== false;
  }
  const createdAt = row ? String(row.createdAt || '') : nowLocalString_();
  if (row) updateObjectRow_(SHEET.USERS, row._row, data);
  else appendObject_(SHEET.USERS, Object.assign({createdAt, lastLoginAt:''}, data));
  audit_('USER_SAVE','USER',email,'','',admin.email,data);
  return {
    ok:true,
    user:{
      email, name:data.name, role:data.role, unitIds:unitIds.slice(),
      directorOffice:role === 'DIRECTOR' ? data.directorOffice : '',
      active:newActive,
      mustChangePassword:newPassword ? data.mustChangePassword === true : (row ? (String(row.mustChangePassword).toUpperCase()==='TRUE' || row.mustChangePassword===true) : false),
      createdAt, updatedAt:data.updatedAt, lastLoginAt:row ? String(row.lastLoginAt || '') : ''
    }
  };
}

function updateSettings(payload) {
  const admin = requireAdmin_();
  payload = payload || {};
  if (payload.defaultTemplateFileId !== undefined) {
    const id = payload.defaultTemplateFileId ? extractDriveId_(payload.defaultTemplateFileId) : '';
    if (id) validateDocxFileId_(id);
    setSettingInternal_('DEFAULT_TEMPLATE_FILE_ID', id, admin.email);
  }
  if (payload.allowedEmailDomain !== undefined) {
    setSettingInternal_('ALLOWED_EMAIL_DOMAIN', String(payload.allowedEmailDomain || '').trim().replace(/^@/, ''), admin.email);
  }
  if (payload.wordDeliveryMode !== undefined) {
    setSettingInternal_('WORD_DELIVERY_MODE', normalizeWordDeliveryMode_(payload.wordDeliveryMode), admin.email);
  }
  if (payload.wordInlineMaxMb !== undefined) {
    setSettingInternal_('WORD_INLINE_MAX_MB', String(normalizeWordInlineMaxMb_(payload.wordInlineMaxMb)), admin.email);
  }
  if (payload.wordDriveSharing !== undefined) {
    setSettingInternal_('WORD_DRIVE_SHARING', normalizeWordSharing_(payload.wordDriveSharing), admin.email);
  }
  audit_('SETTINGS_UPDATE','SYSTEM','SETTINGS','','',admin.email,payload);
  return getSafeSettings_();
}

/** Auth v1.0.1 - 不依賴 Session.getActiveUser()，避免 Web App「以擁有者執行」時無法取得使用者 Email。 */
function getAuthSecret_() {
  let secret = prop_(PROP.AUTH_SECRET);
  if (!secret) {
    secret = Utilities.getUuid() + Utilities.getUuid() + Utilities.getUuid();
    setProp_(PROP.AUTH_SECRET, secret);
  }
  return secret;
}

function createSalt_() {
  return Utilities.getUuid().replace(/-/g,'') + Utilities.getUuid().replace(/-/g,'');
}

function assertPasswordStrength_(password) {
  const p = String(password || '');
  if (p.length < 8) throw new Error('密碼至少需要 8 碼。');
  if (p.length > 128) throw new Error('密碼過長。');
}

function bytesToB64Url_(bytes) {
  return Utilities.base64EncodeWebSafe(bytes).replace(/=+$/,'');
}

function stringToB64Url_(text) {
  return Utilities.base64EncodeWebSafe(String(text), Utilities.Charset.UTF_8).replace(/=+$/,'');
}

function b64UrlToString_(text) {
  let s = String(text || '');
  while (s.length % 4) s += '=';
  return Utilities.newBlob(Utilities.base64DecodeWebSafe(s)).getDataAsString('UTF-8');
}

function hashPassword_(password, salt) {
  const key = getAuthSecret_() + '|' + String(salt || '');
  return bytesToB64Url_(Utilities.computeHmacSha256Signature(String(password || ''), key, Utilities.Charset.UTF_8));
}

function safeEquals_(a,b) {
  a=String(a||''); b=String(b||'');
  if (a.length !== b.length) return false;
  let diff=0;
  for (let i=0;i<a.length;i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff===0;
}

function issueAuthToken_(user) {
  const now = Math.floor(Date.now()/1000);
  const payload = {
    e:String(user.email || '').toLowerCase(),
    iat:now,
    exp:now + APP.AUTH_TOKEN_DAYS*24*60*60,
    uv:String(user.updatedAt || ''),
    n:Utilities.getUuid()
  };
  const body = stringToB64Url_(JSON.stringify(payload));
  const sig = bytesToB64Url_(Utilities.computeHmacSha256Signature(body, getAuthSecret_(), Utilities.Charset.UTF_8));
  return body + '.' + sig;
}

function authenticateToken_(token) {
  const parts = String(token || '').split('.');
  if (parts.length !== 2) throw new Error('請先登入系統。');
  const expected = bytesToB64Url_(Utilities.computeHmacSha256Signature(parts[0], getAuthSecret_(), Utilities.Charset.UTF_8));
  if (!safeEquals_(parts[1], expected)) throw new Error('登入憑證無效，請重新登入。');
  let p;
  try { p = JSON.parse(b64UrlToString_(parts[0])); } catch (err) { throw new Error('登入憑證格式錯誤。'); }
  if (!p.e || Number(p.exp || 0) < Math.floor(Date.now()/1000)) throw new Error('登入已逾期，請重新登入。');
  const user = findOne_(SHEET.USERS, r => String(r.email).toLowerCase() === String(p.e).toLowerCase() && String(r.active).toUpperCase() !== 'FALSE');
  if (!user || !user.passwordHash) throw new Error('帳號不存在、停用或尚未完成密碼設定。');
  if (String(user.updatedAt || '') !== String(p.uv || '')) throw new Error('帳號資料已更新，請重新登入。');
  return user;
}

function login(payload) {
  if (!isSystemSetup_()) throw new Error('系統尚未初始化。');
  ensureSchema_();
  payload = payload || {};
  const email = String(payload.email || '').toLowerCase().trim();
  const password = String(payload.password || '');
  if (!emailMatchesAllowedDomain_(email)) throw new Error('帳號或密碼不正確。');
  const user = findOne_(SHEET.USERS, r => String(r.email).toLowerCase() === email && String(r.active).toUpperCase() !== 'FALSE');
  if (!user || !user.passwordHash || !user.passwordSalt) throw new Error('帳號或密碼不正確。');
  const actual = hashPassword_(password, user.passwordSalt);
  if (!safeEquals_(actual, String(user.passwordHash))) throw new Error('帳號或密碼不正確。');
  const lastLoginAt = nowLocalString_();
  updateObjectRow_(SHEET.USERS, user._row, {lastLoginAt});
  const refreshed = Object.assign({}, user, {lastLoginAt});
  audit_('LOGIN','USER',email,'','',email,{});
  return {ok:true, token:issueAuthToken_(refreshed), user:safeUser_(refreshed)};
}

function changePassword(payload) {
  const user = requireUser_();
  payload = payload || {};
  const oldPassword = String(payload.oldPassword || '');
  const newPassword = String(payload.newPassword || '');
  assertPasswordStrength_(newPassword);
  const row = findOne_(SHEET.USERS, r => String(r.email).toLowerCase() === String(user.email).toLowerCase());
  if (!row) throw new Error('找不到帳號。');
  if (!safeEquals_(hashPassword_(oldPassword,row.passwordSalt), String(row.passwordHash || ''))) throw new Error('目前密碼不正確。');
  const salt = createSalt_();
  updateObjectRow_(SHEET.USERS,row._row,{passwordSalt:salt,passwordHash:hashPassword_(newPassword,salt),mustChangePassword:false,updatedAt:nowLocalString_()});
  const refreshed = findOne_(SHEET.USERS, r => String(r.email).toLowerCase() === String(user.email).toLowerCase());
  audit_('PASSWORD_CHANGE','USER',user.email,'','',user.email,{});
  return {ok:true, token:issueAuthToken_(refreshed), user:safeUser_(refreshed)};
}


function seedDefaultUnitsIfEmpty_() {
  const sh = getSheet_(SHEET.UNITS);
  if (sh.getLastRow() >= 2) return false;
  const headers = sheetHeaders_(SHEET.UNITS);
  const now = nowLocalString_();
  const rows = DEFAULT_UNIT_DEFS.map(u => prepareRowForStorage_(SHEET.UNITS, headers, headers.map(h => ({
    unitId:u.id, office:u.office, label:u.label, color:u.color, sortOrder:u.order,
    active:true, createdAt:now, updatedAt:now
  })[h] !== undefined ? ({
    unitId:u.id, office:u.office, label:u.label, color:u.color, sortOrder:u.order,
    active:true, createdAt:now, updatedAt:now
  })[h] : '')));
  if (rows.length) sh.getRange(2,1,rows.length,headers.length).setValues(rows);
  invalidateUnitSettingsCache_();
  return true;
}

/** V1.2.1 migration：單位資料化、主任處室欄位、會議單位快照、學年度/學期回填。 */
function migrateUnitSettingsV120_() {
  seedDefaultUnitsIfEmpty_();
  const active = activeUnits_();
  const defaultSnapshot = snapshotUnitsJson_(active);

  // 既有處室主任帳號補上 directorOffice，之後新組別加入該處室會自動取得權限。
  const ush = getSheet_(SHEET.USERS);
  const uh = sheetHeaders_(SHEET.USERS);
  const uLast = ush.getLastRow();
  if (uLast >= 2) {
    const roleCol = uh.indexOf('role') + 1, idsCol = uh.indexOf('unitIds') + 1, officeCol = uh.indexOf('directorOffice') + 1;
    const roles = ush.getRange(2,roleCol,uLast-1,1).getValues();
    const ids = ush.getRange(2,idsCol,uLast-1,1).getValues();
    const offices = ush.getRange(2,officeCol,uLast-1,1).getValues();
    const out = offices.map((r,i) => {
      if (String(roles[i][0]).toUpperCase() !== 'DIRECTOR' || String(r[0] || '').trim()) return [r[0] || ''];
      return [inferDirectorOffice_(String(ids[i][0] || '').split(',').filter(Boolean))];
    });
    ush.getRange(2,officeCol,uLast-1,1).setValues(out);
  }

  // 所有既有會議回填學年度、學期及單位快照。之後修改單位設定不會改壞歷史會議。
  const msh = getSheet_(SHEET.MEETINGS);
  const mh = sheetHeaders_(SHEET.MEETINGS);
  const mLast = msh.getLastRow();
  if (mLast >= 2) {
    const dateCol = mh.indexOf('meetingDate') + 1;
    const syCol = mh.indexOf('schoolYear') + 1;
    const semCol = mh.indexOf('semester') + 1;
    const snapCol = mh.indexOf('unitSnapshotJson') + 1;
    const dates = msh.getRange(2,dateCol,mLast-1,1).getValues();
    const snaps = msh.getRange(2,snapCol,mLast-1,1).getValues();
    const syVals=[], semVals=[], snapVals=[];
    dates.forEach((r,i) => {
      try {
        const term = deriveSchoolYearSemester_(r[0]);
        syVals.push([term.schoolYear]); semVals.push([term.semester]);
      } catch (err) { syVals.push(['']); semVals.push(['']); }
      snapVals.push([String(snaps[i][0] || '').trim() || defaultSnapshot]);
    });
    msh.getRange(2,syCol,mLast-1,1).setValues(syVals);
    msh.getRange(2,semCol,mLast-1,1).setValues(semVals);
    msh.getRange(2,snapCol,mLast-1,1).setValues(snapVals);
  }
  invalidateSheetCache_();
  invalidateUnitSettingsCache_();
}

function ensureSchema_() {
  // V1.0.4 效能修正：同一次執行只檢查一次；schema 已是最新時完全不碰試算表。
  // 舊版每一次 API 呼叫都會對 7 張表各做一次 setValues + setFrozenRows（14 次寫入）。
  if (SCHEMA_CHECKED_) return;
  SCHEMA_CHECKED_ = true;
  if (!isSystemSetup_()) return;

  const currentSchema = Number(prop_(PROP.SCHEMA_VERSION) || 0);
  if (currentSchema >= APP.SCHEMA_VERSION) {
    getAuthSecret_();
    return;
  }

  const ss = getDb_();
  Object.keys(HEADERS).forEach(name => {
    let sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    const headers = HEADERS[name];
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    sh.setFrozenRows(1);
  });
  migrateDateStorageV102_();
  migrateUnitSettingsV120_();
  setProp_(PROP.SCHEMA_VERSION, String(APP.SCHEMA_VERSION));
  invalidateSheetCache_();
  getAuthSecret_();
}

/**
 * V1.0.2 資料修復：把 Sheets 自動轉成 Date 的欄位改回穩定的 ISO 純文字。
 * 這個 migration 會在升級後第一次開啟時自動執行，也可從編輯器手動執行 repairDateStorageV102。
 */
function migrateDateStorageV102_() {
  const ss = getDb_();
  Object.keys(DATE_FIELD_TYPES).forEach(sheetName => {
    const sh = ss.getSheetByName(sheetName);
    if (!sh) return;
    const headers = sheetHeaders_(sheetName);
    const lastRow = sh.getLastRow();
    const fieldMap = DATE_FIELD_TYPES[sheetName];
    Object.keys(fieldMap).forEach(field => {
      const col = headers.indexOf(field) + 1;
      if (col <= 0) return;
      // 整個資料欄先設成純文字，避免 setValues 後又被 Sheets 自動判成日期。
      sh.getRange(2, col, Math.max(1, sh.getMaxRows() - 1), 1).setNumberFormat('@');
      if (lastRow >= 2) {
        const range = sh.getRange(2, col, lastRow - 1, 1);
        const values = range.getValues().map(row => {
          const v = row[0];
          if (v === '' || v === null || v === undefined) return [''];
          try {
            return [fieldMap[field] === 'date' ? normalizeDateOnlyValue_(v) : normalizeLocalDateTimeValue_(v)];
          } catch (err) {
            return [String(v)];
          }
        });
        range.setValues(values);
      }
    });
  });
}

function repairDateStorageV102() {
  if (!isSystemSetup_()) throw new Error('系統尚未初始化。');
  migrateDateStorageV102_();
  migrateUnitSettingsV120_();
  setProp_(PROP.SCHEMA_VERSION, String(APP.SCHEMA_VERSION));
  return {ok:true, schemaVersion:APP.SCHEMA_VERSION};
}

function getPublicStatus() {
  if (!isSystemSetup_()) return {setup:false,appName:APP.NAME,version:APP.VERSION,legacyAuthNeedsRepair:false};
  ensureSchema_();
  const admins = getAllObjects_(SHEET.USERS).filter(r => String(r.role).toUpperCase()==='ADMIN' && String(r.active).toUpperCase()!=='FALSE');
  return {
    setup:true, appName:APP.NAME, version:APP.VERSION,
    legacyAuthNeedsRepair:admins.length>0 && admins.every(r => !String(r.passwordHash || '').trim())
  };
}

/**
 * 從舊 V1.0 升級時，請只在 Apps Script 編輯器手動執行一次。
 * 會為原系統擁有者產生暫時密碼，並寫入執行記錄；第一次登入後請立即改密碼。
 */
function repairLegacyAuth() {
  if (!isSystemSetup_()) throw new Error('系統尚未初始化，不需要修復。');
  ensureSchema_();
  const ownerEmail = String(Session.getEffectiveUser().getEmail() || '').toLowerCase().trim();
  if (!ownerEmail) throw new Error('無法取得專案擁有者 Email。請從 Apps Script 編輯器執行此函式。');
  let row = findOne_(SHEET.USERS, r => String(r.email).toLowerCase() === ownerEmail && String(r.role).toUpperCase()==='ADMIN');
  if (!row) row = findOne_(SHEET.USERS, r => String(r.role).toUpperCase()==='ADMIN');
  if (!row) throw new Error('找不到原有管理員帳號。');
  const temp = 'Lj!' + Utilities.getUuid().replace(/-/g,'').slice(0,10) + '7';
  const salt = createSalt_();
  updateObjectRow_(SHEET.USERS,row._row,{passwordSalt:salt,passwordHash:hashPassword_(temp,salt),mustChangePassword:true,updatedAt:nowLocalString_()});
  const result={email:String(row.email),temporaryPassword:temp};
  console.log('=== V1.0.1 暫時管理員帳密 ===');
  console.log(JSON.stringify(result));
  return result;
}

/** UnitService.gs - 單位設定資料化 */
function safeUnitSetting_(u) {
  const x = normalizeUnitSetting_(u);
  return {
    unitId:x.id, id:x.id, office:x.office, label:x.label, color:x.color,
    sortOrder:x.sortOrder, order:x.sortOrder, active:x.active,
    createdAt:x.createdAt, updatedAt:x.updatedAt
  };
}

function listUnitSettings() {
  requireAdmin_();
  return allUnits_().map(safeUnitSetting_);
}

function saveUnitSetting(payload) {
  const admin = requireAdmin_();
  payload = payload || {};
  const all = allUnits_();
  const id = String(payload.unitId || '').trim();
  const existing = id ? all.find(u => u.id === id) : null;
  const office = String(payload.office || '').trim();
  const label = String(payload.label || '').trim();
  if (!office) throw new Error('請輸入處室名稱。');
  if (!label) throw new Error('請輸入組別／單位名稱。');
  if (office.length > 30 || label.length > 30) throw new Error('處室或單位名稱過長。');
  const normalizedLabel = normalizeUnitLabel_(label);
  if (all.some(u => u.id !== id && normalizeUnitLabel_(u.label) === normalizedLabel)) {
    throw new Error('單位名稱不可重複，否則 Word 母版無法判斷要填哪一列。');
  }
  const color = /^#[0-9A-F]{6}$/i.test(String(payload.color || '')) ? String(payload.color).toUpperCase() : '#E9EEF5';
  const maxOrder = all.reduce((m,u) => Math.max(m, Number(u.sortOrder || 0)), 0);
  const sortOrder = Number.isFinite(Number(payload.sortOrder)) ? Math.round(Number(payload.sortOrder)) : maxOrder + 10;
  const active = payload.active !== false;
  if (existing && existing.active && !active && all.filter(u => u.active && u.id !== id).length === 0) {
    throw new Error('至少要保留一個啟用中的單位。');
  }
  const now = nowLocalString_();
  const rowData = {office,label,color,sortOrder,active,updatedAt:now};
  let unitId = id;
  if (existing) {
    const row = getAllObjects_(SHEET.UNITS).find(r => String(r.unitId) === id);
    if (!row) throw new Error('找不到單位資料列。');
    updateObjectRow_(SHEET.UNITS,row._row,rowData);
  } else {
    unitId = 'U_' + uuid_().replace(/-/g,'').slice(0,16).toUpperCase();
    appendObject_(SHEET.UNITS,Object.assign({unitId,createdAt:now},rowData));
  }
  invalidateUnitSettingsCache_();
  audit_('UNIT_SAVE','UNIT',unitId,'','',admin.email,{office,label,color,sortOrder,active});
  return safeUnitSetting_(getUnitDef_(unitId));
}

function setUnitActive(unitId, active) {
  const unit = getUnitDef_(unitId);
  return saveUnitSetting({
    unitId:unit.id, office:unit.office, label:unit.label, color:unit.color,
    sortOrder:unit.sortOrder, active:active === true
  });
}

/** MeetingService.gs - 會議、儀表板 */

function isMeetingTrashed_(m) {
  return !!m && (String(m.trashState || '').toUpperCase() === 'TRASHED' || !!String(m.trashedAt || '').trim());
}

function listMeetingsInternal_() {
  // V1.3.0：舊版排序時每次比較都重新 parse 日期字串（O(n log n) 次）。
  // 改為先算好時間戳再排序，只 parse n 次。
  return getAllObjects_(SHEET.MEETINGS)
    .filter(m => !isMeetingTrashed_(m))
    .map(m => {
      let t = 0;
      try { t = parseDateOnly_(m.meetingDate).getTime(); } catch (err) { t = 0; }
      return {m, t};
    })
    .sort((a,b) => b.t - a.t)
    .map(x => x.m);
}

function listTrashedMeetingsInternal_() {
  return getAllObjects_(SHEET.MEETINGS)
    .filter(isMeetingTrashed_)
    .sort((a,b) => String(b.trashedAt || '').localeCompare(String(a.trashedAt || '')));
}

function listMeetings() {
  requireUser_();
  return listMeetingsInternal_().map(safeMeeting_);
}

function listTrashedMeetings() {
  requireAdmin_();
  return listTrashedMeetingsInternal_().map(safeMeeting_);
}

function safeMeeting_(m) {
  if (!m) return null;
  const meetingDate = normalizeDateOnlyValue_(m.meetingDate);

  let deadlineLocal = '';
  let deadlineEpochMs = 0;
  let hasDeadline = false;
  try {
    deadlineLocal = normalizeLocalDateTimeValue_(m.deadlineLocal);
    if (deadlineLocal) {
      const d = parseLocalDateTime_(deadlineLocal);
      if (d) { deadlineEpochMs = d.getTime(); hasDeadline = true; }
    }
  } catch (err) {
    deadlineLocal = String(m.deadlineLocal || '');
  }

  const trashed = isMeetingTrashed_(m);
  const locked = trashed || String(m.status) === 'CLOSED' || (hasDeadline && now_().getTime() >= deadlineEpochMs);
  let trashedAt = '';
  let purgeAt = '';
  let daysUntilPurge = null;
  if (trashed) {
    try {
      trashedAt = normalizeLocalDateTimeValue_(m.trashedAt);
      const purgeDate = new Date(parseLocalDateTime_(trashedAt).getTime() + 30 * 24 * 60 * 60 * 1000);
      purgeAt = Utilities.formatDate(purgeDate, APP.TIMEZONE, "yyyy-MM-dd'T'HH:mm:ss");
      daysUntilPurge = Math.max(0, Math.ceil((purgeDate.getTime() - now_().getTime()) / (24 * 60 * 60 * 1000)));
    } catch (err) {
      trashedAt = String(m.trashedAt || '');
    }
  }

  return {
    meetingId: String(m.meetingId || ''),
    name: String(m.name || ''),
    meetingDate,
    schoolYear: Number(m.schoolYear || 0),
    semester: Number(m.semester || 0),
    deadlineLocal,
    deadlineEpochMs,
    hasDeadline,
    templateFileId: String(m.templateFileId || ''),
    status: trashed ? 'TRASHED' : (locked ? 'CLOSED' : String(m.status || 'OPEN')),
    locked,
    createdAt: m.createdAt ? normalizeLocalDateTimeValue_(m.createdAt) : '',
    updatedAt: m.updatedAt ? normalizeLocalDateTimeValue_(m.updatedAt) : '',
    trashed,
    trashedAt,
    trashedBy: String(m.trashedBy || ''),
    trashPreviousStatus: String(m.trashPreviousStatus || ''),
    purgeAt,
    daysUntilPurge,
    unitCount:getMeetingUnits_(m).length
  };
}

function getMeetingAnyInternal_(meetingId) {
  const row = findOne_(SHEET.MEETINGS, r => String(r.meetingId) === String(meetingId));
  if (!row) throw new Error('找不到會議。');
  return row;
}

function getMeetingInternal_(meetingId) {
  const row = getMeetingAnyInternal_(meetingId);
  if (isMeetingTrashed_(row)) throw new Error('此會議已移到垃圾桶。');
  return row;
}

function saveMeeting(payload) {
  const admin = requireAdmin_();
  payload = payload || {};
  const meetingDate = normalizeDateOnlyValue_(payload.meetingDate);
  const d = parseDateOnly_(meetingDate);
  const derivedTerm = deriveSchoolYearSemester_(d);
  const requestedSchoolYear = Number(payload.schoolYear);
  const requestedSemester = Number(payload.semester);
  const schoolYear = Number.isFinite(requestedSchoolYear) && requestedSchoolYear >= 90 && requestedSchoolYear <= 300
    ? Math.round(requestedSchoolYear)
    : derivedTerm.schoolYear;
  const semester = [1,2].includes(requestedSemester) ? requestedSemester : derivedTerm.semester;
  const deadlineLocal = normalizeLocalDateTimeValue_(payload.deadlineLocal);
  const deadline = parseLocalDateTime_(deadlineLocal);
  if (deadline.getTime() <= now_().getTime() && !payload.meetingId) throw new Error('新會議的截止時間必須在現在之後。');
  if (deadline.getTime() > d.getTime() + 24*60*60*1000) throw new Error('截止時間不應晚於會議日期後一天，請再確認。');

  let templateFileId = String(payload.templateFileId || '').trim();
  if (templateFileId) {
    templateFileId = extractDriveId_(templateFileId);
    validateDocxFileId_(templateFileId);
  } else {
    templateFileId = getSetting_('DEFAULT_TEMPLATE_FILE_ID', '');
  }

  const id = payload.meetingId ? String(payload.meetingId) : uuid_();
  const existing = payload.meetingId ? getMeetingInternal_(id) : null;
  if (existing && isMeetingLocked_(existing) && String(existing.status) === 'CLOSED') {
    throw new Error('此會議已封存，請先由管理員重新開放後再修改設定。');
  }

  const rowData = {
    meetingId:id,
    name:String(payload.name || `${formatRocDate_(d,'zh')}主任組長會議`).trim(),
    meetingDate,
    schoolYear,
    semester,
    deadlineLocal,
    templateFileId,
    status:String(payload.status || (existing ? existing.status : 'OPEN')).toUpperCase() === 'CLOSED' ? 'CLOSED' : 'OPEN',
    autoDeliver:false,
    notifyEmail:'',
    unitSnapshotJson:(existing && !payload.refreshUnitSnapshot)
      ? (String(existing.unitSnapshotJson || '').trim() || snapshotUnitsJson_(activeUnits_()))
      : snapshotUnitsJson_(activeUnits_()),
    updatedAt:nowLocalString_()
  };

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    if (existing) {
      updateObjectRow_(SHEET.MEETINGS, existing._row, rowData);
    } else {
      appendObject_(SHEET.MEETINGS, Object.assign({
        outputWordFileId:'', reminder24Sent:false, reminder2Sent:false,
        deliveredAt:'', createdBy:admin.email, createdAt:nowLocalString_()
      }, rowData));
    }
  } finally { lock.releaseLock(); }

  audit_('MEETING_SAVE','MEETING',id,id,'',admin.email,rowData);
  return safeMeeting_(getMeetingInternal_(id));
}

function setMeetingClosed(meetingId, closed) {
  const admin = requireAdmin_();
  const meeting = getMeetingInternal_(meetingId);
  updateObjectRow_(SHEET.MEETINGS, meeting._row, {status:closed ? 'CLOSED' : 'OPEN', updatedAt:nowLocalString_()});
  audit_(closed ? 'MEETING_CLOSE' : 'MEETING_REOPEN','MEETING',meetingId,meetingId,'',admin.email,{});
  return safeMeeting_(getMeetingInternal_(meetingId));
}


function moveMeetingToTrash(meetingId) {
  const admin = requireAdmin_();
  const meeting = getMeetingInternal_(meetingId);
  const previousStatus = String(meeting.status || 'OPEN').toUpperCase() === 'CLOSED' ? 'CLOSED' : 'OPEN';
  const trashedAt = nowLocalString_();
  updateObjectRow_(SHEET.MEETINGS, meeting._row, {
    trashState:'TRASHED', trashedAt, trashedBy:admin.email, trashPreviousStatus:previousStatus,
    status:'CLOSED', updatedAt:trashedAt
  });
  audit_('MEETING_TRASH','MEETING',meetingId,meetingId,'',admin.email,{previousStatus,trashedAt});
  return safeMeeting_(getMeetingAnyInternal_(meetingId));
}

function restoreMeetingFromTrash(meetingId) {
  const admin = requireAdmin_();
  const meeting = getMeetingAnyInternal_(meetingId);
  if (!isMeetingTrashed_(meeting)) throw new Error('此會議不在垃圾桶。');
  const restoredStatus = String(meeting.trashPreviousStatus || 'OPEN').toUpperCase() === 'CLOSED' ? 'CLOSED' : 'OPEN';
  updateObjectRow_(SHEET.MEETINGS, meeting._row, {
    trashState:'', trashedAt:'', trashedBy:'', trashPreviousStatus:'', status:restoredStatus, updatedAt:nowLocalString_()
  });
  audit_('MEETING_RESTORE','MEETING',meetingId,meetingId,'',admin.email,{restoredStatus});
  return safeMeeting_(getMeetingInternal_(meetingId));
}

function trashAttachmentFolderIfExists_(meetingId) {
  try {
    const baseId = getSetting_('ATTACHMENT_FOLDER_ID', '');
    const base = baseId ? DriveApp.getFolderById(baseId) : getOrCreateChildFolder_(getRootFolder_(), '使用者附件');
    const it = base.getFoldersByName(String(meetingId));
    while (it.hasNext()) {
      try { it.next().setTrashed(true); } catch (err) { console.warn(err); }
    }
    CacheService.getScriptCache().remove('ATT_FOLDER_V105_' + String(meetingId || ''));
  } catch (err) { console.warn('trashAttachmentFolderIfExists_', err); }
}

function purgeMeetingInternal_(meeting, actorEmail) {
  if (!meeting) return {ok:false};
  const meetingId = String(meeting.meetingId || '');
  if (!meetingId) return {ok:false};

  const attachments = getMeetingAttachments_(meetingId);
  attachments.forEach(a => { try { DriveApp.getFileById(String(a.fileId || '')).setTrashed(true); } catch (err) {} });
  trashIfExists_(meeting.outputWordFileId);
  trashIfExists_(meeting.outputPdfFileId);
  trashAttachmentFolderIfExists_(meetingId);

  audit_('MEETING_PURGE','MEETING',meetingId,meetingId,'',actorEmail || 'SYSTEM_PURGE',{
    name:String(meeting.name || ''), meetingDate:String(meeting.meetingDate || ''), attachmentCount:attachments.length
  });

  const deleted = {
    histories: deleteRowsByFieldValue_(SHEET.REPORT_HISTORY, 'meetingId', meetingId),
    reports: deleteRowsByFieldValue_(SHEET.REPORTS, 'meetingId', meetingId),
    attachments: deleteRowsByFieldValue_(SHEET.ATTACHMENTS, 'meetingId', meetingId),
    meetings: deleteRowsByFieldValue_(SHEET.MEETINGS, 'meetingId', meetingId)
  };
  return {ok:true, meetingId, deleted};
}

function permanentlyDeleteMeeting(meetingId) {
  const admin = requireAdmin_();
  const meeting = getMeetingAnyInternal_(meetingId);
  if (!isMeetingTrashed_(meeting)) throw new Error('請先把會議移到垃圾桶，再執行永久刪除。');
  return purgeMeetingInternal_(meeting, admin.email);
}

function emptyMeetingTrash() {
  const admin = requireAdmin_();
  const items = listTrashedMeetingsInternal_().slice();
  const results = items.map(m => purgeMeetingInternal_(m, admin.email));
  audit_('MEETING_TRASH_EMPTY','SYSTEM','TRASH','','',admin.email,{count:results.length});
  return {ok:true, deleted:results.length};
}

function purgeExpiredTrash_() {
  const cutoff = now_().getTime() - 30 * 24 * 60 * 60 * 1000;
  const expired = listTrashedMeetingsInternal_().filter(m => {
    try { return parseLocalDateTime_(m.trashedAt).getTime() <= cutoff; }
    catch (err) { return false; }
  });
  expired.forEach(m => {
    try { purgeMeetingInternal_(m, 'SYSTEM_PURGE_30D'); }
    catch (err) { console.error('purgeExpiredTrash_ failed', m.meetingId, err); }
  });
  return expired.length;
}

function buildDashboardInternal_(meetingId, user) {
  const meeting = getMeetingInternal_(meetingId);
  const reports = getMeetingReports_(meetingId);
  const byUnit = {};
  reports.forEach(r => byUnit[String(r.unitId)] = r);
  const meetingUnits = getMeetingUnits_(meeting);
  const statuses = meetingUnits.map(u => {
    const r = byUnit[u.id];
    const status = r ? String(r.status || 'DRAFT') : 'NOT_STARTED';
    return {
      unitId:u.id, office:u.office, label:u.label, color:u.color,
      status, noReport:r ? (String(r.noReport).toUpperCase() === 'TRUE' || r.noReport === true) : false,
      updatedAt:r ? String(r.updatedAt || '') : '', submittedAt:r ? String(r.submittedAt || '') : '',
      ownerEmail:r ? String(r.ownerEmail || '') : '',
      canEdit:userCanEditUnit_(user,u.id,u) && !isMeetingLocked_(meeting)
    };
  });
  const submitted = statuses.filter(s => s.status === 'SUBMITTED').length;
  const draft = statuses.filter(s => s.status === 'DRAFT').length;
  return {
    meeting:safeMeeting_(meeting),
    statuses,
    summary:{total:meetingUnits.length, submitted, draft, notStarted:meetingUnits.length-submitted-draft},
    isAdmin:String(user.role).toUpperCase() === 'ADMIN'
  };
}

function getDashboard(meetingId) {
  const user = requireUser_();
  return buildDashboardInternal_(meetingId,user);
}

function validateMeetingTemplate(meetingId) {
  requireAdmin_();
  const meeting = getMeetingInternal_(meetingId);
  const templateId = meeting.templateFileId || getSetting_('DEFAULT_TEMPLATE_FILE_ID','');
  if (!templateId) throw new Error('尚未設定 Word 母版檔案。');
  return validateTemplateInternal_(templateId, getMeetingUnits_(meeting));
}
/** ReportService.gs - 報告編輯、送出 */

/**
 * V1.0.8：編輯器資料短效快取。
 * 長期使用後 Reports / Attachments 工作表會逐年變大；重複開啟同一組別時，
 * 不必每次都整表掃描。所有系統內寫入都會主動失效此快取。
 */
function reportViewCacheKey_(meetingId, unitId) {
  return 'REPORT_VIEW_V108_' + String(meetingId || '') + '_' + String(unitId || '');
}

function invalidateReportViewCache_(meetingId, unitId) {
  try { CacheService.getScriptCache().remove(reportViewCacheKey_(meetingId, unitId)); } catch (err) {}
}

function getReportViewData_(meetingId, unitId) {
  const cache = CacheService.getScriptCache();
  const key = reportViewCacheKey_(meetingId, unitId);
  const hit = cache.get(key);
  if (hit) {
    try {
      const parsed = JSON.parse(hit);
      if (parsed && typeof parsed === 'object') return parsed;
    } catch (err) {}
  }

  const report = findReport_(meetingId, unitId);
  const attachments = getMeetingAttachments_(meetingId).filter(a =>
    String(a.unitId) === String(unitId) &&
    String(a.active).toUpperCase() !== 'FALSE'
  );
  const data = {
    report:report ? safeReport_(report) : null,
    attachments:attachments.map(safeAttachment_)
  };
  try {
    const json = JSON.stringify(data);
    if (json.length < 90000) cache.put(key, json, 90);
  } catch (err) {}
  return data;
}

function getReport(meetingId, unitId) {
  const user = requireUser_();
  const meeting = getMeetingInternal_(meetingId);
  const unit = getMeetingUnitDef_(meeting, unitId);
  assertUnitPermission_(user, unitId, unit);
  const view = getReportViewData_(meetingId, unitId);
  return {
    meeting:safeMeeting_(meeting), unit, locked:isMeetingLocked_(meeting),
    report:view.report || emptyReport_(meetingId,unitId,user.email),
    attachments:view.attachments || []
  };
}

function emptyReport_(meetingId, unitId, ownerEmail) {
  return {reportId:'', meetingId, unitId, ownerEmail, status:'NOT_STARTED', blocks:[], revision:0, updatedAt:'', submittedAt:'', noReport:false};
}

function safeReport_(r) {
  const blocks = safeJsonParse_(r.contentJson, []);
  return {
    reportId:String(r.reportId || ''), meetingId:String(r.meetingId || ''), unitId:String(r.unitId || ''),
    ownerEmail:String(r.ownerEmail || ''), status:String(r.status || 'DRAFT'), blocks:Array.isArray(blocks)?blocks:[],
    revision:Number(r.revision || 0), updatedAt:String(r.updatedAt || ''), submittedAt:String(r.submittedAt || ''),
    noReport:String(r.noReport).toUpperCase() === 'TRUE' || r.noReport === true
  };
}

function validateBlocks_(blocks) {
  if (!Array.isArray(blocks)) throw new Error('報告內容格式錯誤。');
  if (blocks.length > 80) throw new Error('單一組別最多 80 個內容區塊。');
  const clean = [];
  blocks.forEach((b, idx) => {
    b = b || {};
    const type = String(b.type || 'section');
    if (!['section','text','link','image','attachment','table'].includes(type)) throw new Error(`第 ${idx+1} 個內容區塊類型不正確。`);
    if (type === 'section') {
      const title = cleanSectionTitle_(String(b.title || '')).slice(0,300);
      // V1.0.8：草稿可自行輸入標號，但進入資料庫前一律校正為固定四層格式。
      const body = normalizeSectionBody_(String(b.body || '').slice(0,12000)).slice(0,12000);
      const bodyItems = outlineItemsFromBody_(body);
      const maxLine = Math.max(0, bodyItems.length - 1);
      const links = (Array.isArray(b.links) ? b.links : []).slice(0,30).map(x => {
        x = x || {};
        const url = assertSafeUrl_(x.url);
        return {
          lineIndex:Math.max(0, Math.min(maxLine, Math.floor(Number(x.lineIndex || 0)))),
          label:String(x.label || url).trim().slice(0,300),
          url
        };
      });
      clean.push({type, title, body, autoNumber:true, links});
    } else if (type === 'text') {
      clean.push({type, body:String(b.body||'').trim().slice(0,16000)});
    } else if (type === 'link') {
      const url = assertSafeUrl_(b.url);
      clean.push({type, label:String(b.label||url).trim().slice(0,300), url});
    } else if (type === 'image' || type === 'attachment') {
      clean.push({type, attachmentId:String(b.attachmentId||'').trim(), caption:String(b.caption||b.label||'').trim().slice(0,300)});
    } else if (type === 'table') {
      clean.push({type, tsv:String(b.tsv||'').trim().slice(0,18000), header:b.header !== false});
    }
  });
  const json = JSON.stringify(clean);
  if (json.length > APP.MAX_REPORT_JSON_CHARS) throw new Error('報告內容過長，請把大型資料改用附件連結。');
  return {clean, json};
}

function saveReport(payload) {
  return saveReportInternal_(payload, false, false);
}

function submitReport(payload) {
  return saveReportInternal_(payload, true, false);
}

/**
 * V1.0.5 輕量自動儲存：不建立歷史版本、不寫稽核、不增加正式 revision。
 */
function autosaveReport(payload) {
  return saveReportInternal_(payload, false, true);
}


function saveReportInternal_(payload, submit, autosave) {
  const user = requireUser_();
  payload = payload || {};
  const meetingId = String(payload.meetingId || '');
  const unitId = String(payload.unitId || '');
  const meeting = getMeetingInternal_(meetingId);
  const meetingUnit = getMeetingUnitDef_(meeting, unitId);
  assertUnitPermission_(user, unitId, meetingUnit);
  if (isMeetingLocked_(meeting)) throw new Error('已超過截止時間，此會議內容已鎖定。如需修改，請洽文書組長重新開放。');

  const noReport = payload.noReport === true;
  const validated = validateBlocks_(noReport ? [] : (payload.blocks || []));
  if (submit && !noReport && !validated.clean.length) throw new Error('送出前請至少填寫一項報告內容，或勾選「本次無報告事項」。');

  // V1.0.4：一次取出該單位的合法附件再用 map 比對；舊版是每個 id 掃一次整表。
  const usedIds = validated.clean
    .filter(b => b.type === 'image' || b.type === 'attachment')
    .map(b => b.attachmentId).filter(Boolean);
  if (usedIds.length) {
    const validSet = {};
    getMeetingAttachments_(meetingId).filter(x =>
      String(x.unitId) === unitId &&
      String(x.active).toUpperCase() !== 'FALSE'
    ).forEach(a => validSet[String(a.attachmentId)] = true);
    usedIds.forEach(id => {
      if (!validSet[id]) throw new Error('報告引用了不存在或無權限的附件：' + id);
    });
  }

  const lock = LockService.getScriptLock();
  if (autosave) {
    // 多位組長同時編輯時，自動儲存不排 30 秒長隊；忙碌就交給下一輪。
    if (!lock.tryLock(1200)) return {deferred:true};
  } else if (!lock.tryLock(10000)) {
    throw new Error('目前同時儲存人數較多，請稍候數秒再按一次儲存。');
  }
  try {
    let report = findReport_(meetingId, unitId);
    const oldNoReport = report ? (String(report.noReport).toUpperCase() === 'TRUE' || report.noReport === true) : false;
    const targetStatus = submit ? 'SUBMITTED' : 'DRAFT';

    if (autosave && report &&
        String(report.contentJson || '') === validated.json &&
        oldNoReport === noReport &&
        String(report.status || 'DRAFT') === targetStatus) {
      return Object.assign(safeReport_(report), {unchanged:true});
    }

    const currentRevision = report ? Number(report.revision || 0) : 0;
    const nextRevision = autosave ? currentRevision : currentRevision + 1;

    if (!autosave && report && currentRevision > 0) {
      appendObject_(SHEET.REPORT_HISTORY, {
        historyId: uuid_(), reportId: report.reportId, meetingId, unitId, revision: report.revision,
        status: report.status, contentJson: report.contentJson, changedBy: user.email, changedAt: nowLocalString_()
      });
    }

    const reportId = report ? String(report.reportId) : uuid_();
    const updatedAt = nowLocalString_();
    const data = {
      reportId, meetingId, unitId,
      ownerEmail: report ? String(report.ownerEmail || user.email) : user.email,
      status: targetStatus, contentJson: validated.json, revision: nextRevision,
      updatedBy: user.email, updatedAt, submittedAt: submit ? updatedAt : '', noReport
    };
    if (report) updateObjectRow_(SHEET.REPORTS, report._row, data);
    else appendObject_(SHEET.REPORTS, data);
    invalidateReportViewCache_(meetingId, unitId);

    if (!autosave) {
      audit_(submit ? 'REPORT_SUBMIT' : 'REPORT_SAVE', 'REPORT', reportId, meetingId, unitId, user.email,
        {revision: nextRevision, noReport, blockCount: validated.clean.length});
    }
    return Object.assign(safeReport_(data), {autosaved:!!autosave});
  } finally { lock.releaseLock(); }
}

function adminGetReport(meetingId, unitId) {
  requireAdmin_();
  const meeting = getMeetingInternal_(meetingId);
  const view = getReportViewData_(meetingId, unitId);
  return {meeting:safeMeeting_(meeting), unit:getMeetingUnitDef_(meeting, unitId), report:view.report, attachments:view.attachments || []};
}
/** FileService.gs - 附件與母版 */

function validateDocxFileId_(id) {
  const f = DriveApp.getFileById(id);
  const name = f.getName();
  if (!/\.docx$/i.test(name) && f.getMimeType() !== APP.DOCX_MIME) throw new Error('Word 母版必須是 .docx 檔案。');
  return f;
}

function inferMimeTypeFromName_(fileName, declaredMime) {
  const declared = String(declaredMime || '').trim().toLowerCase();
  if (declared && declared !== 'application/octet-stream') return declared;
  const ext = (String(fileName || '').toLowerCase().match(/\.([a-z0-9]+)$/) || [,''])[1];
  const map = {
    pdf:'application/pdf',
    doc:'application/msword',
    docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xls:'application/vnd.ms-excel',
    xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ppt:'application/vnd.ms-powerpoint',
    pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    jpg:'image/jpeg', jpeg:'image/jpeg', png:'image/png'
  };
  return map[ext] || declared || 'application/octet-stream';
}

function uploadAttachment(payload) {
  const user = requireUser_();
  payload = payload || {};
  const meetingId = String(payload.meetingId || '');
  const unitId = String(payload.unitId || '');
  const meeting = getMeetingInternal_(meetingId);
  const meetingUnit = getMeetingUnitDef_(meeting, unitId);
  assertUnitPermission_(user, unitId, meetingUnit);
  if (isMeetingLocked_(meeting)) throw new Error('會議已截止，無法再上傳附件。');

  const fileName = sanitizeFileName_(payload.fileName);
  const mimeType = inferMimeTypeFromName_(fileName, payload.mimeType);
  if (!ALLOWED_UPLOAD_MIME.includes(mimeType)) throw new Error('不支援此檔案類型。僅允許 PDF、Office 文件、JPG、PNG。');
  const bytes = Utilities.base64Decode(String(payload.base64 || ''));
  if (!bytes.length) throw new Error('檔案內容為空。');
  if (bytes.length > APP.MAX_UPLOAD_BYTES) throw new Error('單一附件不得超過 10 MB。');
  const inlineImage = payload.inlineImage === true;
  if (inlineImage && !['image/jpeg','image/png'].includes(mimeType)) throw new Error('正文圖片只支援 JPG 或 PNG。');
  if (inlineImage && bytes.length > APP.INLINE_IMAGE_MAX_BYTES) throw new Error('正文圖片不得超過 8 MB。');

  const blob = Utilities.newBlob(bytes, mimeType, fileName);
  const folder = getAttachmentFolder_(meetingId);
  const file = folder.createFile(blob);
  const attachmentId = uuid_();
  const existingReport = findReport_(meetingId, unitId);
  const data = {
    attachmentId, meetingId, unitId, reportId:existingReport ? existingReport.reportId : '',
    fileId:file.getId(), fileName:file.getName(), mimeType, sizeBytes:bytes.length, fileUrl:file.getUrl(),
    inlineImage, pixelWidth:Number(payload.pixelWidth||0), pixelHeight:Number(payload.pixelHeight||0),
    uploadedBy:user.email, uploadedAt:nowLocalString_(), active:true
  };
  appendObject_(SHEET.ATTACHMENTS, data);
  invalidateReportViewCache_(meetingId, unitId);
  audit_('ATTACHMENT_UPLOAD','ATTACHMENT',attachmentId,meetingId,unitId,user.email,{fileName,mimeType,sizeBytes:bytes.length,inlineImage});
  return safeAttachment_(data);
}

function safeAttachment_(a) {
  return {
    attachmentId:String(a.attachmentId||''), meetingId:String(a.meetingId||''), unitId:String(a.unitId||''),
    fileId:String(a.fileId||''), fileName:String(a.fileName||''), mimeType:String(a.mimeType||''),
    sizeBytes:Number(a.sizeBytes||0), fileUrl:String(a.fileUrl||''), inlineImage:String(a.inlineImage).toUpperCase()==='TRUE'||a.inlineImage===true,
    pixelWidth:Number(a.pixelWidth||0), pixelHeight:Number(a.pixelHeight||0), uploadedAt:String(a.uploadedAt||'')
  };
}


/**
 * V1.0.6 圖片預覽：只在畫面真的需要圖片時才呼叫，避免 getReport / bootstrap 帶入大量 Base64。
 * 優先使用 Drive API 的短效 thumbnailLink；若環境無法取得縮圖，再以 data URL 回傳原圖。
 */
function getAttachmentPreviewSources(attachmentIds, forceBase64) {
  const user = requireUser_();
  const ids = [...new Set((Array.isArray(attachmentIds) ? attachmentIds : []).map(String).filter(Boolean))].slice(0, 6);
  if (!ids.length) return {};
  const rows = getObjectsByFieldValues_(SHEET.ATTACHMENTS, 'attachmentId', ids)
    .filter(a => String(a.active).toUpperCase() !== 'FALSE');
  const out = {};
  const cache = CacheService.getScriptCache();

  rows.forEach(a => {
    const mime = String(a.mimeType || '').toLowerCase();
    if (!['image/jpeg','image/png'].includes(mime)) return;
    if (String(user.role).toUpperCase() !== 'ADMIN') {
      const m = getMeetingInternal_(a.meetingId);
      assertUnitPermission_(user, String(a.unitId || ''), getMeetingUnitDef_(m, a.unitId));
    }

    const attachmentId = String(a.attachmentId);
    const cacheKey = 'IMG_THUMB_V107_' + attachmentId;
    let src = '';

    // V1.0.7：Drive thumbnailLink 跨 RPC 快取 30 分鐘。
    // 編輯器、全份預覽來回切換時，不必每張圖片都重新呼叫 Drive.Files.get()。
    if (!forceBase64) {
      try { src = String(cache.get(cacheKey) || ''); } catch (err) { src = ''; }
      if (!src) {
        try {
          if (typeof Drive !== 'undefined' && Drive.Files) {
            const meta = Drive.Files.get(String(a.fileId), {fields:'thumbnailLink'});
            src = String(meta && meta.thumbnailLink || '');
            if (src) {
              src = src.replace(/=s\d+(-c)?$/, '=s1400');
              try { cache.put(cacheKey, src, 1800); } catch (err) { /* cache best effort */ }
            }
          }
        } catch (err) { console.warn('thumbnailLink unavailable', err); }
      }
    }

    // 縮圖不可用時才回傳 Base64。不要把大型 Base64 放進 CacheService，以免超過單鍵限制。
    if (!src) {
      const blob = DriveApp.getFileById(String(a.fileId)).getBlob();
      const bytes = blob.getBytes();
      if (bytes.length <= APP.INLINE_IMAGE_MAX_BYTES) {
        src = `data:${mime};base64,${Utilities.base64Encode(bytes)}`;
      }
    }
    out[attachmentId] = {src, fileName:String(a.fileName || '圖片')};
  });
  return out;
}

function deleteAttachment(attachmentId) {
  const user = requireUser_();
  const a = getObjectsByFieldValue_(SHEET.ATTACHMENTS, 'attachmentId', String(attachmentId))[0] || null;
  if (!a) throw new Error('附件不存在。');
  const meeting = getMeetingInternal_(a.meetingId);
  assertUnitPermission_(user, a.unitId, getMeetingUnitDef_(meeting, a.unitId));
  if (isMeetingLocked_(meeting)) throw new Error('會議已截止，無法刪除附件。');
  updateObjectRow_(SHEET.ATTACHMENTS, a._row, {active:false});
  invalidateReportViewCache_(a.meetingId, a.unitId);
  try { DriveApp.getFileById(a.fileId).setTrashed(true); } catch (err) { console.warn(err); }
  audit_('ATTACHMENT_DELETE','ATTACHMENT',attachmentId,a.meetingId,a.unitId,user.email,{fileName:a.fileName});
  return {ok:true};
}

function validateTemplateFile(input) {
  requireAdmin_();
  const id = extractDriveId_(input);
  return validateTemplateInternal_(id);
}

function uploadTemplate(payload) {
  const admin = requireAdmin_();
  payload = payload || {};
  const name = sanitizeFileName_(payload.fileName || '主任組長會議母版.docx');
  if (!/\.docx$/i.test(name)) throw new Error('母版檔案必須是 .docx。');
  const bytes = Utilities.base64Decode(String(payload.base64 || ''));
  if (!bytes.length) throw new Error('母版檔案內容為空。');
  if (bytes.length > 20*1024*1024) throw new Error('Word 母版不得超過 20 MB。');
  const folder = getOrCreateChildFolder_(getRootFolder_(),'Word母版');
  const blob = Utilities.newBlob(bytes,APP.DOCX_MIME,name);
  const file = folder.createFile(blob);
  const validation = validateTemplateInternal_(file.getId());
  // V1.2.1：若只是缺少「新成立的單位」，允許上傳；產檔時會動態增補。
  setSettingInternal_('DEFAULT_TEMPLATE_FILE_ID',file.getId(),admin.email);
  audit_('TEMPLATE_UPLOAD','FILE',file.getId(),'','',admin.email,{fileName:name});
  return {ok:true,fileId:file.getId(),fileUrl:file.getUrl(),validation};
}
/**
 * DocxEngine.gs
 * 直接修改 DOCX 的 OOXML，不把 Word 先轉成 Google Docs，目的在最大程度保留文書組原版面。
 * 核心策略：找到每一列左側「組別名稱」，只替換右側內容 cell；欄寬、底色、框線、頁首、頁面設定不動。
 */

function validateTemplateInternal_(templateFileId, requiredUnits) {
  const file = validateDocxFileId_(templateFileId);
  const archive = unzipDocx_(file.getBlob());
  const docXml = getArchiveText_(archive, 'word/document.xml');
  const labels = scanUnitLabelsFromDocument_(docXml);
  const allKnown = allUnits_();
  const required = Array.isArray(requiredUnits) && requiredUnits.length ? requiredUnits : activeUnits_();
  // 歷史會議可能保存舊單位名稱；掃描時同時認得「會議快照名稱」與「目前名稱」。
  const scanUnits = required.concat(allKnown.filter(u => !required.some(r => r.id === u.id && r.label === u.label)));
  const foundIds = [];
  labels.forEach(label => {
    const u = getUnitByLabel_(label, scanUnits);
    if (u && !foundIds.includes(u.id)) foundIds.push(u.id);
  });
  const missing = required.filter(u => !foundIds.includes(u.id)).map(u => ({unitId:u.id,label:u.label,office:u.office}));
  return {
    // V1.2.1：母版缺少新成立的處室／組別，不再視為產檔失敗。
    // generateMeetingDocuments() 會在 Word 尾端或原處室表格中動態補列。
    ok:true,
    complete:missing.length === 0,
    dynamicAppendSupported:true,
    fileId:file.getId(),
    fileName:file.getName(),
    foundUnits:required.filter(u => foundIds.includes(u.id)),
    missingUnits:missing,
    detectedLabels:labels
  };
}


/**
 * V1.2.1：動態 Word 單位／處室版面。
 * Units 已資料化後，Word 母版不可能永遠預先知道未來會成立哪些處室。
 * 因此「母版沒有某單位」改採下列策略：
 * 1. 同處室已存在母版表格：把新單位列加在該處室表格最後。
 * 2. 該處室完全不存在母版：以現有正式報告表格為樣板，在文件尾端新增
 *    「○○處／室報告事項」＋該處室所有缺少的單位列。
 */

function replaceCellVisibleText_(cellXml, text) {
  let replaced = false;
  let out = String(cellXml || '').replace(/(<w:t\b[^>]*>)([\s\S]*?)(<\/w:t>)/g, (m, a, b, c) => {
    if (!replaced) {
      replaced = true;
      return a + xmlEscapeText_(text) + c;
    }
    return a + c;
  });
  if (replaced) return out;

  const openTag = (out.match(/^<w:tc\b[^>]*>/) || ['<w:tc>'])[0];
  const tcPrMatch = out.match(/<w:tcPr\b[\s\S]*?<\/w:tcPr>/);
  const tcPr = tcPrMatch ? tcPrMatch[0] : '';
  return openTag + tcPr + paragraphXml_(text, '', {bold:true}) + '</w:tc>';
}

function setCellFillColor_(cellXml, color) {
  const fill = String(color || '').replace('#','').toUpperCase();
  if (!/^[0-9A-F]{6}$/.test(fill)) return String(cellXml || '');
  let out = String(cellXml || '');
  const tcPr = out.match(/<w:tcPr\b[\s\S]*?<\/w:tcPr>/);
  if (!tcPr) return out;
  let p = tcPr[0];
  if (/<w:shd\b[^>]*\/>/.test(p)) {
    p = p.replace(/<w:shd\b([^>]*)\/>/, (m, attrs) => {
      let a = attrs.replace(/\s+w:fill="[^"]*"/g,'');
      return `<w:shd${a} w:fill="${fill}"/>`;
    });
  } else {
    p = p.replace(/<\/w:tcPr>/, `<w:shd w:val="clear" w:color="auto" w:fill="${fill}"/></w:tcPr>`);
  }
  return out.replace(tcPr[0], p);
}

function replaceRowFirstCell_(rowXml, label, color) {
  const cells = findTopElements_(rowXml, 'w:tc');
  if (!cells.length) return rowXml;
  let first = rowXml.slice(cells[0].start, cells[0].end);
  first = replaceCellVisibleText_(first, label);
  first = setCellFillColor_(first, color);
  return rowXml.slice(0, cells[0].start) + first + rowXml.slice(cells[0].end);
}

function buildSyntheticUnitRow_(sourceRowXml, unit, reportRow, state) {
  let row = replaceRowFirstCell_(sourceRowXml, unit.label, unit.color);
  const cells = findTopElements_(row, 'w:tc');
  if (cells.length < 2) throw new Error('Word 母版沒有可供動態新增單位的雙欄報告列。');
  const oldSecond = row.slice(cells[1].start, cells[1].end);
  const newSecond = buildUnitCellXml_(oldSecond, reportRow || null, unit, state);
  row = row.slice(0, cells[1].start) + newSecond + row.slice(cells[1].end);
  return normalizeDynamicReportRow_(row);
}

function reportOfficeFromHeaderText_(text) {
  const raw = String(text || '').replace(/[\s\u00A0\u3000]+/g,'').trim();
  const suffix = '報告事項';
  if (!raw.endsWith(suffix)) return '';
  return raw.slice(0, -suffix.length);
}

function scanReportTableTemplates_(documentXml, scanUnits) {
  const tables = findTopElements_(documentXml, 'w:tbl');
  const officeTables = {};
  const unitOnlyTables = {};
  let fallback = null;

  tables.forEach(range => {
    const tableXml = documentXml.slice(range.start, range.end);
    const rows = findTopElements_(tableXml, 'w:tr');
    if (!rows.length) return;

    const firstRowXml = tableXml.slice(rows[0].start, rows[0].end);
    const firstCells = findTopElements_(firstRowXml, 'w:tc');
    const firstText = firstCells.length
      ? visibleTextFromXml_(firstRowXml.slice(firstCells[0].start, firstCells[0].end)).trim()
      : '';

    const office = reportOfficeFromHeaderText_(firstText);
    let unitRowTemplate = null;

    for (let i = office ? 1 : 0; i < rows.length; i++) {
      const rowXml = tableXml.slice(rows[i].start, rows[i].end);
      const cells = findTopElements_(rowXml, 'w:tc');
      if (cells.length < 2) continue;
      const label = visibleTextFromXml_(rowXml.slice(cells[0].start, cells[0].end)).trim();
      const unit = getUnitByLabel_(label, scanUnits);
      if (unit) {
        unitRowTemplate = rowXml;
        if (!office && !unitOnlyTables[unit.office]) {
          unitOnlyTables[unit.office] = {range, tableXml, rowTemplate:rowXml};
        }
        break;
      }
    }

    if (office) {
      officeTables[office] = {
        range,
        tableXml,
        rows,
        headerRow:firstRowXml,
        rowTemplate:unitRowTemplate
      };
      if (!fallback && unitRowTemplate) {
        fallback = officeTables[office];
      }
    }
  });

  // 若人事室這類版型「處室標題表」與「主任內容表」分開，
  // fallback 仍由其他正式處室表格提供。
  if (!fallback) {
    const anyUnitOnly = Object.values(unitOnlyTables)[0];
    if (anyUnitOnly) {
      const anyHeader = Object.values(officeTables)[0];
      if (anyHeader) fallback = Object.assign({}, anyHeader, {rowTemplate:anyUnitOnly.rowTemplate});
    }
  }

  return {officeTables, unitOnlyTables, fallback};
}

function rebuildTableWithAppendedRows_(tableXml, newRows) {
  if (!newRows || !newRows.length) return tableXml;
  const close = tableXml.lastIndexOf('</w:tbl>');
  if (close < 0) return tableXml;
  return tableXml.slice(0, close) + newRows.join('') + tableXml.slice(close);
}

function buildDynamicOfficeTable_(reference, office, units, reportByUnit, state) {
  if (!reference || !reference.tableXml || !reference.headerRow || !reference.rowTemplate) {
    throw new Error('Word 母版中找不到可供新增處室使用的正式報告表格樣式。');
  }

  const tableXml = reference.tableXml;
  const rows = findTopElements_(tableXml, 'w:tr');
  if (!rows.length) throw new Error('Word 母版報告表格格式異常。');

  const prefix = tableXml.slice(0, rows[0].start);
  const suffix = tableXml.slice(rows[rows.length - 1].end);

  let header = replaceRowFirstCell_(reference.headerRow, `${office}報告事項`, (units[0] || {}).color);
  // 新處室標題列不需要保留原處室名稱以外的文字。
  const headerCells = findTopElements_(header, 'w:tc');
  if (headerCells.length) {
    let hc = header.slice(headerCells[0].start, headerCells[0].end);
    hc = replaceCellVisibleText_(hc, `${office}報告事項`);
    hc = setCellFillColor_(hc, (units[0] || {}).color);
    header = header.slice(0, headerCells[0].start) + hc + header.slice(headerCells[0].end);
  }

  const unitRows = units.map(unit =>
    buildSyntheticUnitRow_(reference.rowTemplate, unit, reportByUnit[unit.id] || null, state)
  );

  return prefix + header + unitRows.join('') + suffix;
}

function appendMissingUnitsToDocument_(documentXml, missingUnits, reportByUnit, state, scanUnits) {
  if (!missingUnits || !missingUnits.length) return {documentXml, appendedUnitIds:[]};

  const grouped = {};
  missingUnits.forEach(u => {
    if (!grouped[u.office]) grouped[u.office] = [];
    grouped[u.office].push(u);
  });

  const templates = scanReportTableTemplates_(documentXml, scanUnits);
  const replacements = [];
  const absentOffices = [];
  const appended = [];

  Object.keys(grouped).forEach(office => {
    const units = grouped[office];
    const officeTable = templates.officeTables[office];

    if (officeTable && officeTable.rowTemplate) {
      const rows = units.map(unit => {
        appended.push(unit.id);
        return buildSyntheticUnitRow_(officeTable.rowTemplate, unit, reportByUnit[unit.id] || null, state);
      });
      replacements.push({
        start:officeTable.range.start,
        end:officeTable.range.end,
        text:rebuildTableWithAppendedRows_(officeTable.tableXml, rows)
      });
      return;
    }

    // 人事室這類「標題表與內容表分離」的版型：直接加在其單位表最後。
    const unitOnly = templates.unitOnlyTables[office];
    if (unitOnly && unitOnly.rowTemplate) {
      const rows = units.map(unit => {
        appended.push(unit.id);
        return buildSyntheticUnitRow_(unitOnly.rowTemplate, unit, reportByUnit[unit.id] || null, state);
      });
      replacements.push({
        start:unitOnly.range.start,
        end:unitOnly.range.end,
        text:rebuildTableWithAppendedRows_(unitOnly.tableXml, rows)
      });
      return;
    }

    absentOffices.push({office, units});
  });

  replacements.sort((a,b) => b.start - a.start).forEach(r => {
    documentXml = documentXml.slice(0, r.start) + r.text + documentXml.slice(r.end);
  });

  if (absentOffices.length) {
    if (!templates.fallback) {
      throw new Error('Word 母版缺少可供系統建立新處室報告區塊的樣板表格。');
    }
    const dynamicSections = absentOffices.map(group => {
      group.units.forEach(u => appended.push(u.id));
      return '<w:p/>' + buildDynamicOfficeTable_(
        templates.fallback,
        group.office,
        group.units,
        reportByUnit,
        state
      ) + '<w:p/>';
    }).join('');

    const sectPos = documentXml.lastIndexOf('<w:sectPr');
    const bodyClose = documentXml.lastIndexOf('</w:body>');
    const insertPos = sectPos >= 0 ? sectPos : bodyClose;
    if (insertPos < 0) throw new Error('Word 文件結構異常，找不到可插入新處室的位置。');
    documentXml = documentXml.slice(0, insertPos) + dynamicSections + documentXml.slice(insertPos);
  }

  return {documentXml, appendedUnitIds:appended};
}

/* --------------------------------------------------------------------------
 * V1.3.1：Word 交付門檻機制
 *
 * 為什麼需要：產檔完成後要把檔案送到使用者手上，有兩條路。
 *   直接傳輸（inline）— 經 google.script.run 回傳 base64。
 *       優點：不寫 Drive，最快。缺點：base64 膨脹 33%，檔案大就卡在傳輸。
 *   Drive 連結（drive）— 寫入「會議輸出」資料夾，回傳下載網址。
 *       優點：大檔穩定、可重複下載、留存紀錄。缺點：多一次 Drive 寫入。
 *
 * AUTO 模式會依實際位元組大小自動選擇，管理員也可在系統設定強制指定。
 * ------------------------------------------------------------------------ */

function normalizeWordDeliveryMode_(v) {
  const m = String(v || '').trim().toUpperCase();
  return ['AUTO', 'INLINE', 'DRIVE'].indexOf(m) >= 0 ? m : 'AUTO';
}

function normalizeWordInlineMaxMb_(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return APP.WORD_INLINE_MAX_BYTES / 1024 / 1024;
  return Math.max(0.5, Math.min(18, Math.round(n * 10) / 10));
}

function normalizeWordSharing_(v) {
  const m = String(v || '').trim().toUpperCase();
  return ['VIEWER', 'ANYONE_LINK'].indexOf(m) >= 0 ? m : 'VIEWER';
}

/** 決定這一份檔案要走哪條路。回傳 {mode, limitBytes, forced, reason}。 */
function wordDeliveryPlan_(byteLength, requestedMode) {
  const settingMode = normalizeWordDeliveryMode_(getSetting_('WORD_DELIVERY_MODE', 'AUTO'));
  const asked = String(requestedMode || '').trim().toUpperCase();
  const mode = ['AUTO', 'INLINE', 'DRIVE'].indexOf(asked) >= 0 ? asked : settingMode;
  const limitBytes = normalizeWordInlineMaxMb_(getSetting_('WORD_INLINE_MAX_MB', '')) * 1024 * 1024;

  if (mode === 'DRIVE') return {mode:'drive', limitBytes, forced:true, reason:'setting'};

  // 硬上限保護：即使設定強制直傳，也不讓超大 base64 把 RPC 打爆。
  if (byteLength > APP.WORD_INLINE_HARD_MAX_BYTES) {
    return {mode:'drive', limitBytes, forced:true, reason:'hardLimit'};
  }
  if (mode === 'INLINE') return {mode:'inline', limitBytes, forced:true, reason:'setting'};

  return byteLength <= limitBytes
    ? {mode:'inline', limitBytes, forced:false, reason:'underThreshold'}
    : {mode:'drive', limitBytes, forced:false, reason:'overThreshold'};
}

/**
 * 讓管理員拿得到這個檔案。
 * 預設只把「發動產檔的管理員」加為檢視者，不動整體共用設定；
 * 若管理員的系統 Email 不是 Google 帳號（addViewer 會失敗），
 * 或設定選了「知道連結的人」，才退回連結共用。
 */
function shareWordOutputFile_(file, email) {
  const preferred = normalizeWordSharing_(getSetting_('WORD_DRIVE_SHARING', 'VIEWER'));
  if (preferred === 'VIEWER') {
    const e = String(email || '').trim();
    if (e) {
      try { file.addViewer(e); return 'viewer'; }
      catch (err) { console.warn('addViewer failed, fallback to link sharing', err); }
    }
  }
  try {
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    return 'anyoneLink';
  } catch (err) {
    console.warn('link sharing failed', err);
    return 'ownerOnly';
  }
}

/** 寫入「會議輸出」資料夾，並清掉同一場會議過舊的輸出檔，避免 Drive 無限長大。 */
function saveWordOutputToDrive_(wordBlob, fileName, meeting, adminEmail) {
  const folder = getOrCreateChildFolder_(getRootFolder_(), APP.OUTPUT_FOLDER_NAME);
  const stamp = Utilities.formatDate(now_(), APP.TIMEZONE, 'yyyyMMdd_HHmmss');
  const storedName = String(fileName).replace(/\.docx$/i, '') + '_' + stamp + '.docx';
  const file = folder.createFile(wordBlob.copyBlob().setName(storedName));
  const sharing = shareWordOutputFile_(file, adminEmail);

  try {
    updateObjectRow_(SHEET.MEETINGS, meeting._row, {
      outputWordFileId: file.getId(),
      updatedAt: nowLocalString_()
    });
  } catch (err) { console.warn('record outputWordFileId failed', err); }

  purgeOldWordOutputs_(folder, meeting, file.getId());

  return {
    fileId: file.getId(),
    storedName,
    fileUrl: file.getUrl(),
    downloadUrl: 'https://drive.google.com/uc?export=download&id=' + file.getId(),
    sharing
  };
}

function purgeOldWordOutputs_(folder, meeting, keepFileId) {
  try {
    const rocName = formatRocDate_(meeting.meetingDate, 'slash').replace(/\//g, '');
    const prefix = rocName + '主任組長會議_';
    const olds = [];
    const it = folder.getFiles();
    while (it.hasNext()) {
      const f = it.next();
      if (f.getId() === keepFileId) continue;
      if (String(f.getName()).indexOf(prefix) === 0) olds.push(f);
    }
    olds.sort((a, b) => b.getDateCreated().getTime() - a.getDateCreated().getTime());
    olds.slice(Math.max(0, APP.WORD_OUTPUT_KEEP - 1)).forEach(f => {
      try { f.setTrashed(true); } catch (err) { /* 忽略 */ }
    });
  } catch (err) { console.warn('purge old outputs failed', err); }
}

function generateMeetingDocuments(meetingId, options) {
  const startedAt = Date.now();
  const admin = requireAdmin_();
  options = options || {};
  const includeDrafts = options.includeDrafts !== false;
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(3000)) throw new Error('系統正在處理另一項產檔作業，請稍候再試。');

  try {
    const meeting = getMeetingInternal_(meetingId);
    const templateId = String(meeting.templateFileId || getSetting_('DEFAULT_TEMPLATE_FILE_ID', ''));
    if (!templateId) throw new Error('尚未設定 Word 母版。請到「系統設定」或會議設定貼上文書組 .docx 檔案網址。');

    const templateFile = validateDocxFileId_(templateId);
    const archive = unzipDocx_(templateFile.getBlob());
    let documentXml = replaceMeetingMetaInXml_(getArchiveText_(archive, 'word/document.xml'), meeting);

    // 會議建立時已凍結一份單位快照；日後停用、改名或換處室不會改壞歷史會議。
    const meetingUnits = getMeetingUnits_(meeting);
    const meetingUnitMap = Object.fromEntries(meetingUnits.map(u => [u.id,u]));
    const allKnownUnits = allUnits_();
    const scanUnits = meetingUnits.concat(allKnownUnits.filter(u => !meetingUnits.some(m => m.id === u.id && m.label === u.label)));

    // 一次掃描完成母版單位檢查與替換位置定位。母版若仍有已停用單位列，新會議會自動移除該列。
    const unitRows = [];
    const excludedRows = [];
    const foundUnitIds = new Set();
    findTopElements_(documentXml, 'w:tr').forEach(range => {
      const rowXml = documentXml.slice(range.start, range.end);
      const cells = findTopElements_(rowXml, 'w:tc');
      if (cells.length < 2) return;
      const known = getUnitByLabel_(visibleTextFromXml_(rowXml.slice(cells[0].start, cells[0].end)), scanUnits);
      if (!known) return;
      const unit = meetingUnitMap[known.id];
      if (!unit) { excludedRows.push(range); return; }
      foundUnitIds.add(unit.id);
      unitRows.push({range, rowXml, secondRange:cells[1], unit});
    });

    const missingUnits = meetingUnits.filter(u => !foundUnitIds.has(u.id));

    const reportByUnit = {};
    getMeetingReports_(meetingId).forEach(r => reportByUnit[String(r.unitId)] = r);
    const attachmentById = {};
    getMeetingAttachments_(meetingId).filter(a => String(a.active).toUpperCase() !== 'FALSE')
      .forEach(a => attachmentById[String(a.attachmentId)] = a);

    const state = {
      archive,
      relsXml:getArchiveText_(archive, 'word/_rels/document.xml.rels'),
      contentTypesXml:getArchiveText_(archive, '[Content_Types].xml'),
      nextRelId:0,
      nextDocPrId:nextDocPrId_(documentXml),
      attachmentById,
      pendingRels:[],
      imageBlobs:{},
      includeDrafts,
      missingSubmissionUnits:[],
      includedDraftUnits:[],
      notStartedUnits:[],
      dynamicUnitIds:[]
    };
    state.nextRelId = nextRelationshipId_(state.relsXml);

    // V1.3.0 產檔最大加速：所有正文圖片改成一次平行抓取。
    // 舊版在組 XML 的過程中每碰到一張圖就 DriveApp.getFileById().getBlob()，
    // 一張約 0.4～1.5 秒且完全序列化；10 張圖就是 10 倍等待。
    prefetchReportImages_(state, reportByUnit);

    const replacements = excludedRows.map(range => ({start:range.start,end:range.end,text:''})).concat(unitRows.map(item => {
      const newCell = buildUnitCellXml_(
        item.rowXml.slice(item.secondRange.start, item.secondRange.end),
        reportByUnit[item.unit.id] || null,
        item.unit,
        state
      );
      const rebuiltRow =
        item.rowXml.slice(0, item.secondRange.start) +
        newCell +
        item.rowXml.slice(item.secondRange.end);
      return {
        start:item.range.start,
        end:item.range.end,
        text:normalizeDynamicReportRow_(rebuiltRow)
      };
    }));
    documentXml = applyReplacements_(documentXml, replacements);

    // V1.2.1：母版沒有的新單位／新處室，直接動態建立 Word 報告區塊。
    if (missingUnits.length) {
      const dynamicResult = appendMissingUnitsToDocument_(
        documentXml,
        missingUnits,
        reportByUnit,
        state,
        scanUnits
      );
      documentXml = dynamicResult.documentXml;
      state.dynamicUnitIds = dynamicResult.appendedUnitIds;
    }

    Object.keys(archive).filter(name => /^word\/header\d+\.xml$/i.test(name)).forEach(name => {
      setArchiveText_(archive, name, replaceMeetingMetaInXml_(getArchiveText_(archive,name), meeting), 'application/xml');
    });
    setArchiveText_(archive, 'word/document.xml', documentXml, 'application/xml');
    setArchiveText_(archive, 'word/_rels/document.xml.rels', flushRelationships_(state), 'application/xml');
    setArchiveText_(archive, '[Content_Types].xml', state.contentTypesXml, 'application/xml');

    const rocName = formatRocDate_(meeting.meetingDate, 'slash').replace(/\//g, '');
    const fileName = `${rocName}主任組長會議.docx`;
    const wordBlob = zipDocx_(archive, fileName);
    const bytes = wordBlob.getBytes();

    // V1.3.1：依實際檔案大小決定交付方式。
    const plan = wordDeliveryPlan_(bytes.length, options.deliver);
    let delivery = {
      mode: plan.mode,
      thresholdBytes: Math.round(plan.limitBytes),
      forced: !!plan.forced,
      reason: plan.reason
    };
    let base64 = '';
    if (plan.mode === 'inline') {
      base64 = Utilities.base64Encode(bytes);
    } else {
      const saved = saveWordOutputToDrive_(wordBlob, fileName, meeting, admin.email);
      delivery = Object.assign(delivery, saved);
      audit_('DOCUMENT_OUTPUT', 'MEETING', meetingId, meetingId, '', admin.email,
        {fileId: saved.fileId, sizeBytes: bytes.length, sharing: saved.sharing, reason: plan.reason});
    }

    const elapsedMs = Date.now() - startedAt;

    return {
      ok:true,
      fileName,
      mimeType:APP.DOCX_MIME,
      base64,
      delivery,
      sizeBytes:bytes.length,
      elapsedMs,
      includeDrafts,
      dynamicAppendedLabels:state.dynamicUnitIds.map(id => (meetingUnitMap[id] || getUnitDef_(id)).label),
      includedDraftLabels:state.includedDraftUnits.map(id => (meetingUnitMap[id] || getUnitDef_(id)).label),
      notStartedLabels:state.notStartedUnits.map(id => (meetingUnitMap[id] || getUnitDef_(id)).label),
      missingSubmissionLabels:state.missingSubmissionUnits.map(id => (meetingUnitMap[id] || getUnitDef_(id)).label)
    };
  } finally {
    lock.releaseLock();
  }
}


/**
 * V1.2.1：報告列改為動態高度並明確允許跨頁。
 * 母版原列含 w:trHeight；單張圖片通常看不出問題，但連續圖片或長內容時，
 * Word 可能因列高/分頁繼承設定造成後續圖片被壓縮、截斷或看似消失。
 */
function normalizeDynamicReportRow_(rowXml) {
  let out = String(rowXml || '');

  // 內容列不再沿用母版預設列高，交給 Word 依文字與圖片實際高度自動撐開。
  out = out.replace(/<w:trHeight\b[^>]*\/>/g, '');
  out = out.replace(/<w:trHeight\b[^>]*>[\s\S]*?<\/w:trHeight>/g, '');

  // 先移除舊 cantSplit，再明確寫 false，避免表格樣式繼承「列不可跨頁」。
  out = out.replace(/<w:cantSplit\b[^>]*\/>/g, '');
  out = out.replace(/<w:cantSplit\b[^>]*>[\s\S]*?<\/w:cantSplit>/g, '');

  if (/<w:trPr\b[^>]*>/.test(out)) {
    out = out.replace(/(<w:trPr\b[^>]*>)/, '$1<w:cantSplit w:val="0"/>');
  } else {
    out = out.replace(/(<w:tr\b[^>]*>)/, '$1<w:trPr><w:cantSplit w:val="0"/></w:trPr>');
  }
  return out;
}

function imageContentWidthCm_(cellXml) {
  const m = String(cellXml || '').match(/<w:tcW\b[^>]*w:w="(\d+)"[^>]*w:type="dxa"[^>]*\/?>/);
  if (!m) return APP.DEFAULT_IMAGE_WIDTH_CM;
  const cellCm = Number(m[1]) / 1440 * 2.54;
  // 保留左右安全邊界；並維持既有 13.5cm 的視覺比例，不因母版較寬就突然放大。
  return Math.max(6, Math.min(APP.DEFAULT_IMAGE_WIDTH_CM, cellCm - 1.0));
}

/**
 * 圖片段落不沿用文字段落可能存在的 keepNext / 固定行距。
 * 每張圖都是一個獨立 inline drawing 段落，Word 才能正常把下一張推到下一行或下一頁。
 */
function imageParagraphPPr_(pPr) {
  let out = stripNumberingFromPPr_(String(pPr || ''));
  out = out
    .replace(/<w:keepNext\b[^>]*\/>/g, '')
    .replace(/<w:keepNext\b[^>]*>[\s\S]*?<\/w:keepNext>/g, '')
    .replace(/<w:keepLines\b[^>]*\/>/g, '')
    .replace(/<w:keepLines\b[^>]*>[\s\S]*?<\/w:keepLines>/g, '')
    .replace(/<w:pageBreakBefore\b[^>]*\/>/g, '')
    .replace(/<w:pageBreakBefore\b[^>]*>[\s\S]*?<\/w:pageBreakBefore>/g, '')
    .replace(/<w:spacing\b[^>]*\/>/g, '');

  const spacing = '<w:spacing w:before="100" w:after="120"/>';
  if (!out) return `<w:pPr>${spacing}<w:jc w:val="left"/></w:pPr>`;
  if (/<w:jc\b[^>]*\/>/.test(out)) out = out.replace(/<w:jc\b[^>]*\/>/g, '<w:jc w:val="left"/>');
  else out = out.replace(/<\/w:pPr>/, '<w:jc w:val="left"/></w:pPr>');

  // spacing 必須放在 ind / jc 前。
  if (/<w:ind\b/.test(out)) out = out.replace(/<w:ind\b/, `${spacing}<w:ind`);
  else if (/<w:jc\b/.test(out)) out = out.replace(/<w:jc\b/, `${spacing}<w:jc`);
  else out = out.replace(/<\/w:pPr>/, `${spacing}</w:pPr>`);
  return out;
}

function buildUnitCellXml_(oldCellXml, reportRow, unit, state) {
  const openTag = (oldCellXml.match(/^<w:tc\b[^>]*>/) || ['<w:tc>'])[0];
  const tcPrMatch = oldCellXml.match(/<w:tcPr\b[\s\S]*?<\/w:tcPr>/);
  const tcPr = tcPrMatch ? tcPrMatch[0] : '';
  // V1.0.7：從母版的編號定義讀取真正的「文字起點」，讓標題的編號凸排、
  // 內文／圖片則自動縮排到標題文字起點，不再全部貼齊儲存格最左側。
  const pTemplates = paragraphPropertyTemplates_(oldCellXml, state);
  const topPPr = pTemplates.top;
  const bodyPPr = pTemplates.body;
  const continuationLeft = pTemplates.continuationLeft;
  const imageMaxWidthCm = imageContentWidthCm_(oldCellXml);

  let content = '';
  const reportStatus = reportRow ? String(reportRow.status || 'DRAFT').toUpperCase() : 'NOT_STARTED';

  if (!reportRow) {
    state.missingSubmissionUnits.push(unit.id);
    state.notStartedUnits.push(unit.id);
    content += paragraphXml_('（尚未填寫）', bodyPPr, {italic:true, color:'7A271A'});
  } else if (reportStatus === 'DRAFT' && !state.includeDrafts) {
    state.missingSubmissionUnits.push(unit.id);
    content += paragraphXml_('（草稿尚未正式送出）', bodyPPr, {italic:true, color:'B54708'});
  } else {
    if (reportStatus !== 'SUBMITTED') {
      state.missingSubmissionUnits.push(unit.id);
      if (reportStatus === 'DRAFT') state.includedDraftUnits.push(unit.id);
    }

    if (String(reportRow.noReport).toUpperCase() === 'TRUE' || reportRow.noReport === true) {
      content += paragraphXml_('本次無報告事項。', bodyPPr, {});
    } else {
      const blocks = safeJsonParse_(reportRow.contentJson, []);
    if (!Array.isArray(blocks) || !blocks.length) {
      content += paragraphXml_(
        reportStatus === 'DRAFT' ? '（草稿尚無內容）' : '本次無報告事項。',
        bodyPPr,
        reportStatus === 'DRAFT' ? {italic:true, color:'B54708'} : {}
      );
    } else {
      let sectionCounter = 0;
      for (let bi = 0; bi < blocks.length; bi++) {
        const block = blocks[bi];
        if (!block || !block.type) continue;

        if (block.type === 'section') {
          sectionCounter++;
          let sectionXml = sectionBlockXml_(block, topPPr, bodyPPr, sectionCounter, continuationLeft, state);
          const childImages = [];

          // 緊接在 section 後面的 image / attachment 都視為該條列的附屬內容。
          let j = bi + 1;
          while (j < blocks.length && blocks[j] && (blocks[j].type === 'image' || blocks[j].type === 'attachment')) {
            const child = blocks[j];
            const a = state.attachmentById[String(child.attachmentId)];
            if (a && child.type === 'attachment') {
              // 附件連結不另起一行，直接放到最後一段文字尾端。
              sectionXml = appendAttachmentLinkToSectionTail_(
                sectionXml,
                child.caption || `附件：${a.fileName}`,
                a.fileUrl,
                state
              );
            } else if (a && child.type === 'image') {
              childImages.push({block:child, attachment:a});
            }
            j++;
          }

          content += sectionXml;
          childImages.forEach((x, imageIndex) => {
            content += imageParagraphXml_(
              x.attachment,
              bodyPPr,
              state,
              {
                maxWidthCm:imageMaxWidthCm,
                sequenceCount:childImages.length,
                sequenceIndex:imageIndex
              }
            );
            if (x.block.caption) content += paragraphXml_(x.block.caption, bodyPPr, {italic:true, align:'center'});
          });
          bi = j - 1;
          continue;
        }

        if (block.type === 'text') {
          splitNonEmptyLines_(block.body).forEach(line => content += paragraphXml_(line, bodyPPr, {}));
        } else if (block.type === 'link') {
          content += hyperlinkParagraphXml_(block.label || block.url, block.url, bodyPPr, state);
        } else if (block.type === 'attachment') {
          // 沒有依附在 section 的附件，仍以獨立段落保留。
          const a = state.attachmentById[String(block.attachmentId)];
          if (a) content += hyperlinkParagraphXml_(block.caption || `附件：${a.fileName}`, a.fileUrl, bodyPPr, state);
        } else if (block.type === 'image') {
          const a = state.attachmentById[String(block.attachmentId)];
          if (a) {
            content += imageParagraphXml_(
              a,
              bodyPPr,
              state,
              {maxWidthCm:imageMaxWidthCm, sequenceCount:1, sequenceIndex:0}
            );
            if (block.caption) content += paragraphXml_(block.caption, bodyPPr, {italic:true, align:'center'});
          }
        } else if (block.type === 'table') {
          content += tableBlockXml_(block.tsv, block.header !== false, unit.color, bodyPPr);
        }
      }
    }
    }
  }
  if (!content) content = paragraphXml_('',bodyPPr,{});
  // Word 表格儲存格最後必須有 paragraph；若最後一個 block 是 nested table，補一個空段落。
  if (!/<w:p\b[\s\S]*<\/w:p>\s*$/.test(content)) content += paragraphXml_('',bodyPPr,{});
  return openTag + tcPr + content + '</w:tc>';
}

function sectionBlockXml_(block, topPPr, bodyPPr, sectionCounter, continuationLeft, state) {
  let title = cleanSectionTitle_(block.title);
  let bodyItems = outlineItemsFromBody_(block.body);

  if (!title && bodyItems.length) {
    title = String(bodyItems.shift().text || '').trim();
    bodyItems = outlineItemsFromBody_(bodyItems.map(x => `${x.prefix} ${x.text}`).join('\n'));
  }
  if (!title) return '';

  // V1.0.8：四層編號改由系統直接產生文字，不依賴母版 numbering.xml 是否能自動續號。
  const basePPr = stripNumberingFromPPr_(topPPr || bodyPPr);
  const level1PPr = outlineParagraphPPr_(basePPr, continuationLeft, 1);
  const headingText = `${outlinePrefix_(1, sectionCounter)}【${title}】`;
  let xml = paragraphXml_(headingText, level1PPr, {bold:true});

  const inlineLinks = Array.isArray(block.links) ? block.links : [];
  bodyItems.forEach((item, itemIndex) => {
    // 標號與文字直接相接；縮排由 hanging 控制。
    let pXml = outlineBodyParagraphXml_(
      item.prefix,
      item.text || '',
      bodyPPr || basePPr,
      continuationLeft,
      item.level
    );
    // V1.2.1：網頁連結不再獨立成段，直接接在指定文字敘述後面。
    inlineLinks.filter(x => Number(x && x.lineIndex) === itemIndex).forEach(x => {
      pXml = appendInlineLinkToParagraph_(pXml, x.label || x.url, x.url, state);
    });
    xml += pXml;
  });
  return xml;
}

function splitNonEmptyLines_(text) {
  return String(text || '').replace(/\r/g,'').split('\n').map(s=>s.trim()).filter(Boolean);
}

function paragraphPropertyTemplates_(cellXml, state) {
  const pMatches = cellXml.match(/<w:p\b[\s\S]*?<\/w:p>/g) || [];
  const pprs = pMatches.slice(0,20).map(p => {
    const m = p.match(/<w:pPr\b[\s\S]*?<\/w:pPr>/);
    return m ? m[0] : '';
  }).filter(Boolean);
  const defaultPPr = '<w:pPr><w:pStyle w:val="TableParagraph"/><w:spacing w:line="360" w:lineRule="auto"/><w:jc w:val="both"/></w:pPr>';
  const top = pprs.find(p => /<w:numPr\b/.test(p)) || pprs[0] || defaultPPr;
  const bodyBase = pprs.find(p => !/<w:numPr\b/.test(p)) || stripNumberingFromPPr_(top) || defaultPPr;

  // 母版第一層文字起點仍作為整份四層編號的基準。
  // V1.2.1：縮排採固定 hanging；(一) 與正文緊接，第三層標號直接接在第二層正文起點。
  const indent = listIndentFromNumbering_(top, state);
  const continuationLeft = Number(indent.left || 480) || 480;
  const body = setParagraphIndent_(bodyBase, continuationLeft, 0);
  return {top, body, continuationLeft};
}

function stripNumberingFromPPr_(ppr) {
  return String(ppr || '').replace(/<w:numPr\b[\s\S]*?<\/w:numPr>/g,'');
}

/**
 * 取得 Word 清單的「文字起點」。
 * 例：母版 numId=4 / ilvl=0 為 left=480、hanging=480：
 *   一、【標題】   ← 編號凸到左側
 *      內文……     ← 從 480 twips 開始
 */
function listIndentFromNumbering_(ppr, state) {
  const fallback = {left:480, hanging:480};
  const numPr = String(ppr || '').match(/<w:numPr\b[\s\S]*?<\/w:numPr>/);
  if (!numPr) return fallback;
  const numIdM = numPr[0].match(/<w:numId\b[^>]*w:val="([^"]+)"[^>]*\/?>(?:<\/w:numId>)?/);
  const ilvlM = numPr[0].match(/<w:ilvl\b[^>]*w:val="([^"]+)"[^>]*\/?>(?:<\/w:ilvl>)?/);
  if (!numIdM) return fallback;
  const numId = String(numIdM[1]);
  const ilvl = String(ilvlM ? ilvlM[1] : '0');

  let numberingXml = '';
  try {
    if (state && state.archive && state.archive['word/numbering.xml']) {
      numberingXml = getArchiveText_(state.archive, 'word/numbering.xml');
    }
  } catch (err) { numberingXml = ''; }
  if (!numberingXml) return fallback;

  const numRe = new RegExp('<w:num\\b[^>]*w:numId="' + escapeRegex_(numId) + '"[^>]*>([\\s\\S]*?)<\\/w:num>');
  const numM = numberingXml.match(numRe);
  if (!numM) return fallback;
  const absIdM = numM[1].match(/<w:abstractNumId\b[^>]*w:val="([^"]+)"[^>]*\/?>(?:<\/w:abstractNumId>)?/);
  if (!absIdM) return fallback;

  const absRe = new RegExp('<w:abstractNum\\b[^>]*w:abstractNumId="' + escapeRegex_(String(absIdM[1])) + '"[^>]*>([\\s\\S]*?)<\\/w:abstractNum>');
  const absM = numberingXml.match(absRe);
  if (!absM) return fallback;
  const lvlRe = new RegExp('<w:lvl\\b[^>]*w:ilvl="' + escapeRegex_(ilvl) + '"[^>]*>([\\s\\S]*?)<\\/w:lvl>');
  const lvlM = absM[1].match(lvlRe);
  if (!lvlM) return fallback;
  const indM = lvlM[1].match(/<w:ind\b[^>]*\/?>(?:<\/w:ind>)?/);
  if (!indM) return fallback;
  const leftM = indM[0].match(/w:left="(\d+)"/);
  const hangingM = indM[0].match(/w:hanging="(\d+)"/);
  return {
    left:leftM ? Number(leftM[1]) : fallback.left,
    hanging:hangingM ? Number(hangingM[1]) : fallback.hanging
  };
}

/** 套用段落縮排；hanging=0 代表一般左縮排，>0 代表凸排。 */
function setParagraphIndent_(ppr, leftTwips, hangingTwips) {
  let out = String(ppr || '');
  const left = Math.max(0, Math.round(Number(leftTwips || 0)));
  const hanging = Math.max(0, Math.round(Number(hangingTwips || 0)));
  const ind = `<w:ind w:left="${left}"${hanging ? ` w:hanging="${hanging}"` : ''}/>`;
  if (!out) return `<w:pPr>${ind}</w:pPr>`;
  out = out
    .replace(/<w:ind\b[^>]*\/>/g,'')
    .replace(/<w:ind\b[\s\S]*?<\/w:ind>/g,'');
  // w:pPr 的子元素順序有規範：w:ind 必須在 w:jc / w:rPr 之前。
  // 直接塞在 </w:pPr> 前雖然部分 Word 版本會自動修復，但也可能造成縮排被忽略。
  if (/<w:jc\b/.test(out)) return out.replace(/<w:jc\b/, `${ind}<w:jc`);
  if (/<w:rPr\b/.test(out)) return out.replace(/<w:rPr\b/, `${ind}<w:rPr`);
  if (/<\/w:pPr>/.test(out)) return out.replace(/<\/w:pPr>/, `${ind}</w:pPr>`);
  return `<w:pPr>${ind}</w:pPr>`;
}


function paragraphXml_(text, pPr, opts) {
  opts = opts || {};
  let finalPPr = String(pPr || '');
  if (opts.align) {
    // V1.0.4：pPr 為空字串時舊版會整個丟掉對齊設定。
    if (!finalPPr) {
      finalPPr = `<w:pPr><w:jc w:val="${opts.align}"/></w:pPr>`;
    } else {
      finalPPr = finalPPr.replace(/<w:jc\b[^>]*\/>/g, '');
      finalPPr = finalPPr.replace(/<\/w:pPr>/, `<w:jc w:val="${opts.align}"/></w:pPr>`);
    }
  }
  return `<w:p>${finalPPr}${runXml_(text, opts)}</w:p>`;
}

function runXml_(text,opts) {
  opts = opts || {};
  // Word 的 w:sz / w:szCs 單位為 half-point；24 = 12pt。
  // 不再讓母版的 11pt 隱性繼承到系統產生的文字。
  let rPr = '<w:sz w:val="24"/><w:szCs w:val="24"/>';
  if (opts.bold) rPr += '<w:b/>';
  if (opts.italic) rPr += '<w:i/>';
  if (opts.color) rPr += `<w:color w:val="${xmlEscapeAttr_(opts.color)}"/>`;
  if (opts.underline) rPr += '<w:u w:val="single"/>';
  const t = xmlEscapeText_(String(text === undefined ? '' : text));
  const preserve = /^\s|\s$/.test(String(text || '')) ? ' xml:space="preserve"' : '';
  return `<w:r><w:rPr>${rPr}</w:rPr><w:t${preserve}>${t}</w:t></w:r>`;
}

function hyperlinkRunXml_(label,url,state) {
  url = String(url || '').trim();
  if (!isSafeUrl_(url)) return runXml_(String(label || url), {});
  const rid = addRelationship_(state,'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',url,true);
  const text = xmlEscapeText_(String(label || url));
  return `<w:hyperlink r:id="${rid}"><w:r><w:rPr><w:sz w:val="24"/><w:szCs w:val="24"/><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr><w:t>${text}</w:t></w:r></w:hyperlink>`;
}

function hyperlinkParagraphXml_(label,url,pPr,state) {
  return `<w:p>${pPr}${hyperlinkRunXml_(label,url,state)}</w:p>`;
}

/** 將一般網頁連結直接接在指定文字段落尾端，不另起一行。 */
function appendInlineLinkToParagraph_(paragraphXml, label, url, state) {
  const p = String(paragraphXml || '');
  const pos = p.lastIndexOf('</w:p>');
  if (pos < 0) return p;
  const tail = `${runXml_('　', {})}${hyperlinkRunXml_(label || url, url, state)}`;
  return p.slice(0, pos) + tail + p.slice(pos);
}

/** 將附件連結直接接在某一 section 最後一個文字段落尾端。 */
function appendAttachmentLinkToSectionTail_(sectionXml, label, url, state) {
  const pos = String(sectionXml || '').lastIndexOf('</w:p>');
  if (pos < 0) return sectionXml + hyperlinkParagraphXml_(label,url,'',state);
  const tail = `${runXml_('　', {})}${hyperlinkRunXml_(label,url,state)}`;
  return sectionXml.slice(0,pos) + tail + sectionXml.slice(pos);
}


/**
 * V1.3.0：把整份會議會用到的正文圖片，一次以 UrlFetchApp.fetchAll() 平行下載。
 * fetchAll 會同時發出所有請求，總時間趨近「最慢的那一張」而不是「全部相加」。
 * 任何一張失敗都只是回退到原本的 DriveApp 單張抓取，不影響產檔成功率。
 */
function prefetchReportImages_(state, reportByUnit) {
  const ids = [];
  const seen = {};
  Object.keys(reportByUnit || {}).forEach(unitId => {
    const row = reportByUnit[unitId];
    if (!row) return;
    const blocks = safeJsonParse_(row.contentJson, []);
    if (!Array.isArray(blocks)) return;
    blocks.forEach(b => {
      if (!b || b.type !== 'image') return;
      const id = String(b.attachmentId || '');
      if (!id || seen[id]) return;
      const a = state.attachmentById[id];
      if (!a) return;
      if (!['image/jpeg','image/png'].includes(String(a.mimeType || ''))) return;
      seen[id] = true;
      ids.push(id);
    });
  });
  if (!ids.length) return;

  let token = '';
  try { token = ScriptApp.getOAuthToken(); } catch (err) { token = ''; }
  if (!token) return;

  // 記憶體保護：一次平行拉太多大圖可能撞到 Apps Script 記憶體上限，
  // 因此分批（每批最多 8 張、累計 24MB），批與批之間仍是平行的。
  const BATCH_MAX_COUNT = 8;
  const BATCH_MAX_BYTES = 24 * 1024 * 1024;

  const batches = [];
  let current = [];
  let currentBytes = 0;
  ids.forEach(id => {
    const size = Math.max(0, Number(state.attachmentById[id].sizeBytes || 0)) || 1024 * 1024;
    if (current.length >= BATCH_MAX_COUNT || (current.length && currentBytes + size > BATCH_MAX_BYTES)) {
      batches.push(current);
      current = [];
      currentBytes = 0;
    }
    current.push(id);
    currentBytes += size;
  });
  if (current.length) batches.push(current);

  batches.forEach(batch => {
    const requests = batch.map(id => ({
      url: 'https://www.googleapis.com/drive/v3/files/' +
           encodeURIComponent(String(state.attachmentById[id].fileId)) +
           '?alt=media&supportsAllDrives=true',
      method: 'get',
      headers: {Authorization: 'Bearer ' + token},
      muteHttpExceptions: true
    }));
    try {
      const responses = UrlFetchApp.fetchAll(requests);
      responses.forEach((res, i) => {
        try {
          if (!res || res.getResponseCode() !== 200) return;
          state.imageBlobs[batch[i]] = res.getBlob();
        } catch (err) { /* 單張失敗就讓它走原本的 DriveApp 路徑 */ }
      });
    } catch (err) {
      console.warn('image prefetch batch failed, fallback to DriveApp', err);
    }
  });
}

function imageParagraphXml_(attachment, pPr, state, opts) {
  opts = opts || {};
  const mime = String(attachment.mimeType || '');
  if (!['image/jpeg', 'image/png'].includes(mime)) return '';

  const ext = mime === 'image/png' ? 'png' : 'jpg';
  const mediaName = `report_${uuid_().replace(/-/g, '')}.${ext}`;
  const archivePath = `word/media/${mediaName}`;
  const prefetched = state.imageBlobs && state.imageBlobs[String(attachment.attachmentId || '')];
  const sourceBlob = prefetched || DriveApp.getFileById(String(attachment.fileId)).getBlob();
  state.archive[archivePath] = sourceBlob.copyBlob().setName(archivePath);
  ensureContentType_(state, ext, mime);
  const rid = addRelationship_(
    state,
    'http://schemas.openxmlformats.org/officeDocument/2006/relationships/image',
    `media/${mediaName}`,
    false
  );

  const pxW = Math.max(0, Number(attachment.pixelWidth || 0));
  const pxH = Math.max(0, Number(attachment.pixelHeight || 0));

  // 圖片永遠限制在儲存格/頁面可用寬度內。
  const maxWidthCm = Math.max(6, Math.min(16.5, Number(opts.maxWidthCm || APP.DEFAULT_IMAGE_WIDTH_CM)));

  // 連續兩張以上圖片時，略縮小單張最大高度，降低一張圖把整頁吃滿的機率。
  // Word 仍可把後續圖片自然推到下一頁，不會重疊或消失。
  const sequenceCount = Math.max(1, Number(opts.sequenceCount || 1));
  const maxHeightCm = sequenceCount > 1 ? 11.5 : 16.0;

  let widthCm = maxWidthCm;
  let heightCm;

  if (pxW > 0 && pxH > 0) {
    heightCm = widthCm * pxH / pxW;
    if (heightCm > maxHeightCm) {
      heightCm = maxHeightCm;
      widthCm = heightCm * pxW / pxH;
    }
  } else {
    // 舊附件若沒有像素資訊，採安全的 16:9 預設，不讓圖片高度失控。
    heightCm = Math.min(maxHeightCm, widthCm * 9 / 16);
  }

  // 再做一次雙向邊界保護。
  if (widthCm > maxWidthCm) {
    const ratio = maxWidthCm / widthCm;
    widthCm *= ratio;
    heightCm *= ratio;
  }
  if (heightCm > maxHeightCm) {
    const ratio = maxHeightCm / heightCm;
    widthCm *= ratio;
    heightCm *= ratio;
  }

  const cx = Math.max(1, Math.round(widthCm * 360000));
  const cy = Math.max(1, Math.round(heightCm * 360000));
  const docPrId = state.nextDocPrId++;
  const name = xmlEscapeAttr_(attachment.fileName || mediaName);

  // 關鍵：圖片使用專用段落屬性，不繼承文字固定行距 / keepNext。
  const imagePPr = imageParagraphPPr_(pPr);

  return `<w:p>${imagePPr}<w:r><w:drawing>` +
    `<wp:inline xmlns:wp="${NS_WP_}" distT="0" distB="0" distL="0" distR="0">` +
    `<wp:extent cx="${cx}" cy="${cy}"/>` +
    `<wp:effectExtent l="0" t="0" r="0" b="0"/>` +
    `<wp:docPr id="${docPrId}" name="${name}"/>` +
    `<wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="${NS_A_}" noChangeAspect="1"/></wp:cNvGraphicFramePr>` +
    `<a:graphic xmlns:a="${NS_A_}">` +
    `<a:graphicData uri="${NS_PIC_}">` +
    `<pic:pic xmlns:pic="${NS_PIC_}">` +
    `<pic:nvPicPr><pic:cNvPr id="${docPrId}" name="${name}"/><pic:cNvPicPr/></pic:nvPicPr>` +
    `<pic:blipFill><a:blip r:embed="${rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>` +
    `<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm>` +
    `<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>` +
    `</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>`;
}

function tableBlockXml_(tsv,hasHeader,color,pPr) {
  const rows = String(tsv || '').replace(/\r/g,'').split('\n').filter(x=>x.trim()).slice(0,30).map(line=>line.split('\t').slice(0,12));
  if (!rows.length) return '';
  const cols = Math.max.apply(null,rows.map(r=>r.length));
  const width = Math.floor(9000/Math.max(cols,1));
  let grid=''; for(let i=0;i<cols;i++) grid += `<w:gridCol w:w="${width}"/>`;
  let xml = `<w:tbl><w:tblPr><w:tblW w:w="0" w:type="auto"/><w:tblBorders><w:top w:val="single" w:sz="6" w:color="000000"/><w:left w:val="single" w:sz="6" w:color="000000"/><w:bottom w:val="single" w:sz="6" w:color="000000"/><w:right w:val="single" w:sz="6" w:color="000000"/><w:insideH w:val="single" w:sz="4" w:color="666666"/><w:insideV w:val="single" w:sz="4" w:color="666666"/></w:tblBorders></w:tblPr><w:tblGrid>${grid}</w:tblGrid>`;
  rows.forEach((row,ri)=>{
    xml += '<w:tr>';
    for(let ci=0;ci<cols;ci++) {
      const fill = hasHeader && ri===0 ? `<w:shd w:val="clear" w:color="auto" w:fill="${String(color||'#EDEDED').replace('#','')}"/>` : '';
      const text = row[ci] === undefined ? '' : row[ci];
      xml += `<w:tc><w:tcPr><w:tcW w:w="${width}" w:type="dxa"/>${fill}</w:tcPr><w:p>${stripNumberingFromPPr_(pPr)}${runXml_(text,{bold:hasHeader&&ri===0})}</w:p></w:tc>`;
    }
    xml += '</w:tr>';
  });
  xml += '</w:tbl>';
  return xml;
}

/**
 * V1.3.0：每新增一個超連結／圖片就重寫一次 rels 全文，等於 O(k²)。
 * 改成先推進陣列，產檔尾端 flushRelationships_() 一次合併。
 */
function addRelationship_(state,type,target,external) {
  const rid = 'rId' + (state.nextRelId++);
  if (!state.pendingRels) state.pendingRels = [];
  state.pendingRels.push(
    `<Relationship Id="${rid}" Type="${xmlEscapeAttr_(type)}" Target="${xmlEscapeAttr_(target)}"${external?' TargetMode="External"':''}/>`
  );
  return rid;
}

function flushRelationships_(state) {
  if (!state.pendingRels || !state.pendingRels.length) return state.relsXml;
  const block = state.pendingRels.join('');
  state.pendingRels = [];
  state.relsXml = String(state.relsXml).replace(/<\/Relationships>\s*$/, block + '</Relationships>');
  return state.relsXml;
}

function nextRelationshipId_(relsXml) {
  let max = 0, m;
  const re = /Id="rId(\d+)"/g;
  while ((m = re.exec(String(relsXml)))) max = Math.max(max,Number(m[1]));
  return max + 1;
}

function nextDocPrId_(documentXml) {
  let max=0,m;
  const re=/<wp:docPr\b[^>]*\bid="(\d+)"/g;
  while((m=re.exec(String(documentXml)))) max=Math.max(max,Number(m[1]));
  return max+1;
}

function ensureContentType_(state,ext,mime) {
  const re = new RegExp(`<Default\\s+Extension="${escapeRegex_(ext)}"\\s+ContentType="[^"]+"\\s*\\/>`,'i');
  if (re.test(state.contentTypesXml)) return;
  const node = `<Default Extension="${xmlEscapeAttr_(ext)}" ContentType="${xmlEscapeAttr_(mime)}"/>`;
  state.contentTypesXml = String(state.contentTypesXml).replace(/<\/Types>\s*$/,node+'</Types>');
}

function replaceMeetingMetaInXml_(xml,meeting) {
  // V1.3.0：原本三個 regex 各掃一次全文（每次都重建 <w:t> 索引再整份重組）。
  // 改成單次掃描、單次重組。母版頁首 + 內文加起來可省下數百毫秒到數秒。
  return replaceTextNodesByRules_(String(xml), [
    {regex:/\d{3}\s*學年度第\s*\d\s*學期/g, replacement:`${meeting.schoolYear} 學年度第 ${meeting.semester} 學期`},
    {regex:/\d{3}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日\s*主任組長會議/g, replacement:meetingDisplayTitle_(meeting)},
    {regex:/\d{3}\.\d{1,2}\.\d{1,2}/g, replacement:formatRocDate_(meeting.meetingDate,'dot')}
  ]);
}

function replaceTextNodesByRegex_(xml,regex,replacement) {
  return replaceTextNodesByRules_(xml, [{regex, replacement}]);
}

/**
 * 把 Word 拆散在多個 <w:t> 的文字先接成一條可見字串，
 * 依序套用多組 regex，再把結果寫回原本的節點位置。
 */
function replaceTextNodesByRules_(xml, rules) {
  const src = String(xml);
  const list = (rules || []).filter(r => r && r.regex);
  if (!list.length) return src;

  const nodes = [];
  const re = /<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g;
  let m;
  const parts = [];
  let concatLen = 0;
  while((m=re.exec(src))) {
    const visible = decodeXmlText_(m[1]);
    const openEnd = m[0].indexOf('>') + 1;
    const closeStart = m[0].lastIndexOf('</w:t>');
    nodes.push({innerStart:m.index + openEnd,innerEnd:m.index + closeStart,text:visible,start:concatLen,end:concatLen+visible.length});
    parts.push(visible);
    concatLen += visible.length;
  }
  if (!nodes.length) return src;
  const concat = parts.join('');

  // 收集所有 rule 的命中區段（同一段文字先命中者優先，避免互相覆蓋）。
  const matches = [];
  list.forEach(rule => {
    const flags = rule.regex.flags.indexOf('g') >= 0 ? rule.regex.flags : rule.regex.flags + 'g';
    const rr = new RegExp(rule.regex.source, flags);
    let mm;
    while((mm = rr.exec(concat))) {
      matches.push({start:mm.index, end:mm.index + mm[0].length, replacement:String(rule.replacement === undefined ? '' : rule.replacement)});
      if (mm[0].length === 0) rr.lastIndex++;
    }
  });
  if (!matches.length) return src;

  matches.sort((a,b) => a.start - b.start || b.end - a.end);
  const picked = [];
  let guard = -1;
  matches.forEach(x => { if (x.start >= guard) { picked.push(x); guard = x.end; } });

  // 用二分搜尋定位受影響節點，避免每個 match 都線性掃全部節點。
  const starts = nodes.map(x => x.start);
  const lowerBound = v => {
    let lo = 0, hi = starts.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (starts[mid] < v) lo = mid + 1; else hi = mid; }
    return lo;
  };

  const edits = [];
  picked.forEach(mm => {
    let i = Math.max(0, lowerBound(mm.start) - 1);
    while (i < nodes.length && nodes[i].end <= mm.start) i++;
    const affected = [];
    for (let j = i; j < nodes.length && nodes[j].start < mm.end; j++) {
      if (nodes[j].end > mm.start) affected.push(nodes[j]);
    }
    if (!affected.length) return;
    const first = affected[0], last = affected[affected.length - 1];
    const prefix = first.text.slice(0, Math.max(0, mm.start - first.start));
    const suffix = last.text.slice(Math.max(0, mm.end - last.start));
    affected.forEach((nd, idx) => {
      const value = idx === 0
        ? prefix + mm.replacement + (affected.length === 1 ? suffix : '')
        : (idx === affected.length - 1 ? suffix : '');
      edits.push({start:nd.innerStart, end:nd.innerEnd, text:xmlEscapeText_(value)});
    });
  });

  return applyReplacements_(src, edits);
}

function scanUnitLabelsFromDocument_(xml) {
  const labels=[];
  findTopElements_(xml,'w:tr').forEach(r=>{
    const row=xml.slice(r.start,r.end);
    const cells=findTopElements_(row,'w:tc');
    if(cells.length>=2) {
      const left=row.slice(cells[0].start,cells[0].end);
      const t=visibleTextFromXml_(left).trim();
      if(t) labels.push(t);
    }
  });
  return labels;
}

/** 找到同名 element 的最外層片段，找到一個後直接跳過其完整範圍，因此 nested 元素不會被誤當成同層。 */
function findTopElements_(xml,tag) {
  const results=[];
  let pos=0;
  const token='<'+tag;
  while(true) {
    const start=xml.indexOf(token,pos);
    if(start<0) break;
    const end=findMatchingElementEnd_(xml,start,tag);
    if(end<0) break;
    results.push({start,end});
    pos=end;
  }
  return results;
}

const TAG_SCAN_REGEX_CACHE_ = {};

function findMatchingElementEnd_(xml,start,tag) {
  // V1.3.0：母版有數百個 <w:tr>／<w:tc>，舊版每次都重新編譯同一組 regex。
  let re = TAG_SCAN_REGEX_CACHE_[tag];
  if (!re) {
    re = new RegExp(`<\\/?${escapeRegex_(tag)}\\b[^>]*>`,'g');
    TAG_SCAN_REGEX_CACHE_[tag] = re;
  }
  re.lastIndex=start;
  let depth=0,m;
  while((m=re.exec(xml))) {
    const tok=m[0];
    const isClose=tok.indexOf('</')===0;
    const selfClose=/\/>$/.test(tok);
    if(isClose) depth--;
    else if(!selfClose) depth++;
    if(depth===0) return re.lastIndex;
  }
  return -1;
}

function visibleTextFromXml_(xml) {
  const texts=[];
  const re=/<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g;
  let m;
  while((m=re.exec(String(xml)))) texts.push(decodeXmlText_(m[1]));
  return texts.join('');
}

function decodeXmlText_(s) {
  return String(s||'').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,'&');
}

function xmlEscapeText_(s) {
  return String(s===undefined?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function xmlEscapeAttr_(s) {
  return xmlEscapeText_(s).replace(/"/g,'&quot;').replace(/'/g,'&apos;');
}

function escapeRegex_(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
}

/**
 * V1.3.0：一次套用多段字串替換。
 * 舊寫法在迴圈裡反覆做 str.slice(0,a) + text + str.slice(b)，
 * 每一次都是整份 document.xml（動輒數 MB）的完整複製；
 * 20 個單位就是 40 次全文複製。改為單次線性掃描 + join。
 */
function applyReplacements_(text, replacements) {
  const src = String(text || '');
  const list = (replacements || [])
    .filter(r => r && Number.isFinite(Number(r.start)) && Number.isFinite(Number(r.end)))
    .map(r => ({start:Number(r.start), end:Number(r.end), text:String(r.text === undefined ? '' : r.text)}))
    .sort((a,b) => a.start - b.start);
  if (!list.length) return src;

  const out = [];
  let cursor = 0;
  for (let i = 0; i < list.length; i++) {
    const r = list[i];
    if (r.start < cursor) continue;   // 重疊區段保護：忽略被前一段吃掉的替換
    out.push(src.slice(cursor, r.start));
    out.push(r.text);
    cursor = r.end;
  }
  out.push(src.slice(cursor));
  return out.join('');
}

function unzipDocx_(blob) {
  if (!blob) throw new Error('DOCX 內容不存在。');

  // DOCX 的實體格式是 ZIP 封裝，但 Drive 取回的 Blob MIME 會是
  // application/vnd.openxmlformats-officedocument.wordprocessingml.document。
  // Apps Script 的 Utilities.unzip() 會驗證輸入 ContentType 必須是 application/zip，
  // 因此不能直接把 file.getBlob() 傳入；必須以相同位元組重新包成 ZIP Blob。
  const sourceName = String(blob.getName() || 'document.docx');
  const zipInput = Utilities.newBlob(
    blob.getBytes(),
    APP.ZIP_MIME,
    sourceName.replace(/\.docx$/i,'') + '.zip'
  );

  let arr;
  try {
    arr = Utilities.unzip(zipInput);
  } catch (err) {
    throw new Error('Word 母版無法解壓縮。請確認檔案是真正的 .docx，而不是改副檔名的舊 .doc 或損毀檔案。原始錯誤：' + (err && err.message ? err.message : err));
  }

  const map={};
  arr.forEach(b=>map[b.getName()]=b);
  if(!map['word/document.xml']) throw new Error('此檔案不是可解析的 DOCX：缺少 word/document.xml');
  return map;
}

function getArchiveText_(archive,name) {
  const b=archive[name];
  if(!b) throw new Error('DOCX 缺少必要檔案：'+name);
  return b.getDataAsString('UTF-8');
}

function setArchiveText_(archive,name,text,mime) {
  archive[name]=Utilities.newBlob(String(text),mime||'application/xml',name);
}

function zipDocx_(archive,fileName) {
  // V1.3.0：名稱已正確的 Blob 不再多做一次 copyBlob()。
  // 一份含圖 DOCX 常有 40～80 個項目，省下的是整份位元組的重複複製。
  const blobs=Object.keys(archive).sort().map(name=>{
    const b=archive[name];
    try { if (b.getName()===name) return b; } catch (err) { /* 極少數 Blob 取名失敗，走複製 */ }
    return b.copyBlob().setName(name);
  });

  // Utilities.zip() 產生的是 application/zip Blob。某些 Apps Script 執行環境
  // 不允許直接對該 Blob setContentType(DOCX_MIME)，會出現
  //「ContentType 應為 application/zip」。因此先完成 ZIP，再以同一組 bytes
  // 建立新的 DOCX MIME Blob，避免改變 ZIP Blob 本身的 ContentType。
  const zipName = String(fileName || 'document.docx').replace(/\.docx$/i,'') + '.zip';
  const zipBlob = Utilities.zip(blobs,zipName);
  return Utilities.newBlob(zipBlob.getBytes(),APP.DOCX_MIME,String(fileName || 'document.docx'));
}
/** TriggerService.gs - 截止提醒與自動鎖定 */

function installSystemTriggers() {
  const admin = requireAdmin_();
  installSystemTriggersInternal_();
  audit_('TRIGGER_INSTALL','SYSTEM','TRIGGERS','','',admin.email,{});
  return {ok:true};
}

function installSystemTriggersInternal_() {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === APP.TRIGGER_HANDLER) ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger(APP.TRIGGER_HANDLER).timeBased().everyMinutes(15).create();
}

function deadlineSweep() {
  try { return deadlineSweepInternal_(); } finally { try { flushAuditBuffer_(); } catch (err) { console.error(err); } }
}

function deadlineSweepInternal_() {
  if (!isSystemSetup_()) return;
  purgeExpiredTrash_();
  // 5 年後可能累積數百場會議；排程只處理仍開放的會議，不重掃歷年 CLOSED 資料。
  const meetings = listMeetingsInternal_().filter(m => String(m.status || 'OPEN').toUpperCase() !== 'CLOSED');
  const nowMs = now_().getTime();
  meetings.forEach(meeting => {
    try {
      const deadline = parseLocalDateTime_(meeting.deadlineLocal);
      const delta = deadline.getTime() - nowMs;
      if (delta > 0) {
        if (delta <= 2*60*60*1000 && String(meeting.reminder2Sent).toUpperCase() !== 'TRUE' && getSetting_('REMINDER_2H','TRUE') === 'TRUE') {
          sendPendingReminder_(meeting,'2 小時');
          updateObjectRow_(SHEET.MEETINGS,meeting._row,{reminder2Sent:true,reminder24Sent:true,updatedAt:nowLocalString_()});
        } else if (delta <= 24*60*60*1000 && String(meeting.reminder24Sent).toUpperCase() !== 'TRUE' && getSetting_('REMINDER_24H','TRUE') === 'TRUE') {
          sendPendingReminder_(meeting,'24 小時');
          updateObjectRow_(SHEET.MEETINGS,meeting._row,{reminder24Sent:true,updatedAt:nowLocalString_()});
        }
      } else {
        if (String(meeting.status) !== 'CLOSED') updateObjectRow_(SHEET.MEETINGS,meeting._row,{status:'CLOSED',updatedAt:nowLocalString_()});
      }
    } catch (err) {
      console.error('deadlineSweep meeting failed',meeting.meetingId,err);
      audit_('TRIGGER_ERROR','MEETING',meeting.meetingId,meeting.meetingId,'','SYSTEM_TRIGGER',{message:String(err && err.message || err)});
    }
  });
}

function sendPendingReminder_(meeting,label) {
  const reports = getMeetingReports_(meeting.meetingId);
  const submitted = new Set(reports.filter(r => String(r.status) === 'SUBMITTED').map(r => String(r.unitId)));
  const pending = getMeetingUnits_(meeting).filter(u => !submitted.has(u.id));
  if (!pending.length) return;
  const users = getAllObjects_(SHEET.USERS).filter(u => String(u.active).toUpperCase() !== 'FALSE');
  const recipientMap = {};
  pending.forEach(unit => {
    users.forEach(u => {
      const ids = String(u.unitIds || '').split(',').map(x=>x.trim()).filter(Boolean);
      u.unitIdsArray = ids;
      if (userCanEditUnit_(u, unit.id, unit)) {
        const email = String(u.email || '').trim();
        if (!email) return;
        if (!recipientMap[email]) recipientMap[email]=[];
        if (!recipientMap[email].some(x=>x.id===unit.id)) recipientMap[email].push(unit);
      }
    });
  });
  Object.keys(recipientMap).forEach(email => {
    const unitLabels = recipientMap[email].map(u=>u.label).join('、');
    const subject = `【提醒】${meetingDisplayTitle_(meeting)}報告事項剩餘 ${label}`;
    const body = [
      `${meetingDisplayTitle_(meeting)}報告事項尚未完成正式送出：${unitLabels}`,
      `截止時間：${normalizeLocalDateTimeValue_(meeting.deadlineLocal).replace('T',' ')}`,
      '',
      '請於截止前登入主任組長會議報告彙整系統完成送出。',
      '截止後系統會鎖定，需由管理員重新開放才可修改。'
    ].join('\n');
    MailApp.sendEmail({to:email,subject,body,name:APP.NAME});
  });
  audit_('REMINDER_SEND','MEETING',meeting.meetingId,meeting.meetingId,'','SYSTEM_TRIGGER',{label,pending:pending.map(u=>u.id),recipients:Object.keys(recipientMap)});
}


/**
 * V1.2.1 系統健檢：只讀各表 row count / trigger / 設定，不載入大型 contentJson。
 * 供管理員每學期或版本升級後檢查，不增加日常登入負擔。
 */
function getSystemHealth() {
  requireAdmin_();
  const counts = {};
  let allocatedCells = 0;
  Object.keys(HEADERS).forEach(name => {
    const sh = getSheet_(name);
    counts[name] = Math.max(0, sh.getLastRow() - 1);
    allocatedCells += sh.getMaxRows() * sh.getMaxColumns();
  });
  const triggers = ScriptApp.getProjectTriggers().map(t => ({handler:t.getHandlerFunction(), eventType:String(t.getEventType())}));
  const templateId = String(getSetting_('DEFAULT_TEMPLATE_FILE_ID',''));
  let templateOk = false;
  let templateName = '';
  let templateMissingLabels = [];
  if (templateId) {
    try {
      const validation = validateTemplateInternal_(templateId);
      templateName = validation.fileName || '';
      templateOk = !!validation.ok;
      templateMissingLabels = (validation.missingUnits || []).map(x => x.label);
    } catch (err) {}
  }
  const warnings = [];
  if (counts.Reports > 6000) warnings.push('Reports 已超過 6,000 筆；目前已使用索引欄位讀取，可繼續使用，建議每學年做一次效能檢查。');
  if (counts.ReportHistory > 20000) warnings.push('ReportHistory 已超過 20,000 筆；建議規劃年度封存，但不要直接刪除近兩學年的版本。');
  if (counts.AuditLog > 30000) warnings.push('AuditLog 已超過 30,000 筆；可考慮封存 2 年前稽核紀錄。');
  if (allocatedCells > 8000000) warnings.push('Google Sheets 已配置超過 800 萬格，接近平台上限；請安排資料封存。');
  if (!templateOk) warnings.push(templateMissingLabels.length ? 'Word 母版缺少：' + templateMissingLabels.join('、') : '預設 Word 母版目前無法讀取，產檔前請重新指定。');
  if (!triggers.some(t => t.handler === APP.TRIGGER_HANDLER)) warnings.push('截止提醒排程不存在，請重新安裝系統排程。');
  return {
    version:APP.VERSION,
    schemaVersion:Number(prop_(PROP.SCHEMA_VERSION) || 0),
    counts,
    allocatedCells,
    triggerCount:triggers.length,
    deadlineTriggerInstalled:triggers.some(t => t.handler === APP.TRIGGER_HANDLER),
    templateOk, templateName, templateMissingLabels,
    warnings,
    checkedAt:nowLocalString_()
  };
}

/** 管理員手動備份中央資料庫；保留最近 12 份，避免備份本身無限長大。 */
function createDatabaseBackup() {
  const admin = requireAdmin_();
  const dbId = prop_(PROP.DB_ID);
  if (!dbId) throw new Error('找不到中央資料庫。');
  const folder = getOrCreateChildFolder_(getRootFolder_(), '系統備份');
  const stamp = Utilities.formatDate(now_(), APP.TIMEZONE, 'yyyyMMdd_HHmmss');
  const file = DriveApp.getFileById(dbId).makeCopy(`${APP.DB_NAME}_backup_${stamp}`, folder);

  const backups = [];
  const it = folder.getFiles();
  while (it.hasNext()) {
    const f = it.next();
    if (String(f.getName()).startsWith(APP.DB_NAME + '_backup_')) backups.push(f);
  }
  backups.sort((a,b) => b.getDateCreated().getTime() - a.getDateCreated().getTime());
  backups.slice(12).forEach(f => { try { f.setTrashed(true); } catch (err) {} });
  audit_('DATABASE_BACKUP','SYSTEM','DB','','',admin.email,{backupFileId:file.getId(),name:file.getName()});
  return {ok:true, fileId:file.getId(), fileName:file.getName(), fileUrl:file.getUrl(), retained:Math.min(backups.length,12)};
}

/** 單一 RPC 入口：所有前端操作都經過此處驗證登入 token。 */

function api(request) {
  request = request || {};
  const action = String(request.action || '');
  const args = Array.isArray(request.args) ? request.args : [];

  if (action === 'getPublicStatus') return getPublicStatus();
  if (action === 'setupSystem') return setupSystem(args[0] || {});
  if (action === 'login') return login(args[0] || {});

  if (!isSystemSetup_()) throw new Error('系統尚未初始化。');
  ensureSchema_();
  REQUEST_USER_ = authenticateToken_(String(request.token || ''));
  try {
    const handlers = {
      getBootstrap, getBootstrapLite, prefetchMyReports,
      getDashboard, getReport, saveReport, autosaveReport, submitReport,
      uploadAttachment, deleteAttachment, getAttachmentPreviewSources, listUsers, saveUser, updateSettings,
      listMeetings, listTrashedMeetings, saveMeeting, setMeetingClosed, moveMeetingToTrash,
      restoreMeetingFromTrash, permanentlyDeleteMeeting, emptyMeetingTrash, validateMeetingTemplate,
      validateTemplateFile, uploadTemplate, generateMeetingDocuments,
      installSystemTriggers, adminGetReport, changePassword,
      copyPreviousReport, sendManualReminder, getMeetingFullPreview, listReportHistory,
      getSystemHealth, createDatabaseBackup, listUnitSettings, saveUnitSetting, setUnitActive
    };
    const fn = handlers[action];
    if (!fn) throw new Error('不允許的操作：' + action);
    return fn.apply(null, args);
  } finally {
    try { flushAuditBuffer_(); } catch (err) { console.error(err); }
    REQUEST_USER_ = null;
    invalidateSheetCache_();
  }
}

/** Code.gs - Web App 入口 */
function doGet() {
  const t = HtmlService.createTemplateFromFile('Index');
  t.appName = APP.NAME;
  t.appVersion = APP.VERSION;
  return t.evaluate()
    .setTitle(APP.NAME)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.DEFAULT);
}

function getBootstrap(preferredMeetingId) {
  if (!isSystemSetup_()) {
    return {setup:false, appName:APP.NAME, version:APP.VERSION};
  }
  const user = requireUser_();
  const meetings = listMeetingsInternal_();
  const defaultMeeting = chooseDefaultMeeting_(meetings);
  const preferred = String(preferredMeetingId || '');
  const isAdmin = String(user.role).toUpperCase() === 'ADMIN';

  // 組長／編輯者每次重新進入系統都以「最新建立且仍可填報」的會議為主，
  // 不讓先前停留的舊會議 ID 把畫面卡在上一期。管理員仍可保留自己正在檢視的歷史會議。
  const target = (isAdmin && preferred && meetings.find(m => String(m.meetingId) === preferred)) || defaultMeeting;
  return {
    setup:true,
    appName:APP.NAME,
    version:APP.VERSION,
    user:safeUser_(user),
    units:activeUnits_(),
    directorOffices:directorOffices_(),
    meetings:meetings.map(safeMeeting_),
    defaultMeetingId:defaultMeeting ? String(defaultMeeting.meetingId) : '',
    trashCount:listTrashedMeetingsInternal_().length,
    dashboard:target ? buildDashboardInternal_(target.meetingId, user) : null,
    settings:isAdmin ? getSafeSettings_() : null
  };
}

/**
 * V1.3.0：給前端「先畫骨架」用的輕量啟動包。
 * 只回傳身分、導覽與會議清單，不做 dashboard 彙整，
 * 讓使用者在 300～600ms 內就看到完整版面，而不是空白等待。
 */
function getBootstrapLite() {
  if (!isSystemSetup_()) return {setup:false, appName:APP.NAME, version:APP.VERSION};
  const user = requireUser_();
  const meetings = listMeetingsInternal_();
  const defaultMeeting = chooseDefaultMeeting_(meetings);
  const isAdmin = String(user.role).toUpperCase() === 'ADMIN';
  return {
    setup:true,
    lite:true,
    appName:APP.NAME,
    version:APP.VERSION,
    user:safeUser_(user),
    units:activeUnits_(),
    directorOffices:directorOffices_(),
    meetings:meetings.map(safeMeeting_),
    defaultMeetingId:defaultMeeting ? String(defaultMeeting.meetingId) : '',
    settings:isAdmin ? getSafeSettings_() : null
  };
}

/**
 * V1.3.0：一次把使用者自己負責的單位報告全部取回，讓「開啟編輯器」變成即時。
 * 前端在總覽頁閒置時背景呼叫，使用者真的點下去時已經有資料。
 */
function prefetchMyReports(meetingId, unitIds) {
  const user = requireUser_();
  const meeting = getMeetingInternal_(meetingId);
  const wanted = (Array.isArray(unitIds) ? unitIds : []).map(String).filter(Boolean).slice(0, 12);
  const out = {};
  wanted.forEach(unitId => {
    try {
      const unit = getMeetingUnitDef_(meeting, unitId);
      if (!userCanEditUnit_(user, unitId, unit)) return;
      const view = getReportViewData_(meetingId, unitId);
      out[unitId] = {
        meeting:safeMeeting_(meeting), unit, locked:isMeetingLocked_(meeting),
        report:view.report || emptyReport_(meetingId, unitId, user.email),
        attachments:view.attachments || []
      };
    } catch (err) { /* 單一單位失敗不影響其他 */ }
  });
  return out;
}

function chooseDefaultMeeting_(meetings) {
  if (!meetings.length) return null;
  const nowMs = now_().getTime();
  const fillable = meetings.filter(m => {
    if (String(m.status || '').toUpperCase() === 'CLOSED') return false;
    try { return parseLocalDateTime_(m.deadlineLocal).getTime() > nowMs; }
    catch (err) { return false; }
  });

  // 「最新要填寫」直接以會議日期較新者優先。
  // 例如同時存在 8/21 測試會議與 8/24 正式會議，組長預設一定會進到 8/24。
  fillable.sort((a,b) =>
    (parseDateOnly_(b.meetingDate).getTime() - parseDateOnly_(a.meetingDate).getTime()) ||
    String(b.createdAt || '').localeCompare(String(a.createdAt || ''))
  );
  if (fillable.length) return fillable[0];

  return meetings.slice().sort((a,b) => parseDateOnly_(b.meetingDate).getTime() - parseDateOnly_(a.meetingDate).getTime())[0];
}

/* ==========================================================================
 * 效能與操作模組
 * --------------------------------------------------------------------------
 * - 資料表快取與 schema 檢查旗標
 * - 圖片縮圖快取、輸出資料夾快取
 * - 一鍵帶入上次內容、手動催繳、全份預覽、歷史版本
 * ========================================================================== */

/** 同一次執行內的資料表快取。寫入時必須呼叫 invalidateSheetCache_。 */
const SHEET_CACHE_ = {};

/** schema 是否已在本次執行檢查過。 */
let SCHEMA_CHECKED_ = false;

/** DrawingML namespace，產生正文圖片時必須就地宣告。 */
const NS_WP_ = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing';
const NS_A_ = 'http://schemas.openxmlformats.org/drawingml/2006/main';
const NS_PIC_ = 'http://schemas.openxmlformats.org/drawingml/2006/picture';

function invalidateSheetCache_(sheetName) {
  if (sheetName) {
    delete SHEET_CACHE_[sheetName];
    Object.keys(TARGET_QUERY_CACHE_).forEach(k => { if (k.startsWith(sheetName + '|')) delete TARGET_QUERY_CACHE_[k]; });
  } else {
    Object.keys(SHEET_CACHE_).forEach(k => delete SHEET_CACHE_[k]);
    Object.keys(TARGET_QUERY_CACHE_).forEach(k => delete TARGET_QUERY_CACHE_[k]);
  }
  // Apps Script 執行環境可能重用全域變數；每個 RPC 結束時同步清掉單位快取，
  // 讓管理員在 Units 工作表或系統介面調整後，下一次請求一定讀到新設定。
  if (!sheetName || sheetName === SHEET.UNITS) {
    UNIT_SETTINGS_CACHE_.all = null;
    UNIT_SETTINGS_CACHE_.active = null;
  }
}

/** Settings 整張表一次讀完，避免每個 getSetting_ 都整表掃描。 */
let SETTINGS_MAP_CACHE_ = null;
function getSettingsMap_() {
  if (SETTINGS_MAP_CACHE_) return SETTINGS_MAP_CACHE_;

  // V1.3.0：Settings 幾乎不變，但每次 bootstrap / 產檔都要讀。改為跨請求快取。
  const warm = readSmallSheetCache_(SHEET.SETTINGS);
  if (warm) {
    SETTINGS_MAP_CACHE_ = warm;
    return SETTINGS_MAP_CACHE_;
  }
  const map = {};
  getAllObjects_(SHEET.SETTINGS).forEach(r => map[String(r.key)] = String(r.value));
  writeSmallSheetCache_(SHEET.SETTINGS, map);
  SETTINGS_MAP_CACHE_ = map;
  return map;
}

/* --------------------------------------------------------------------------
 * V1.3.0 小型資料表跨請求快取（Units / Settings）
 * 這兩張表資料量小、變動極少，卻是每一次 RPC 的必讀項目。
 * 以「資料版本號」當快取 key，任何寫入只要 bump 一次，全部節點立刻失效，
 * 不會有改了設定卻要等 6 小時的問題。
 * ------------------------------------------------------------------------ */

const SMALL_SHEET_CACHE_TTL_ = 21600;

function dataVersion_() {
  let v = prop_('LJ_MEETING_DATA_VERSION');
  if (!v) { v = '1'; setProp_('LJ_MEETING_DATA_VERSION', v); }
  return String(v);
}

function bumpDataVersion_() {
  const next = String((Number(prop_('LJ_MEETING_DATA_VERSION') || 0) || 0) + 1);
  setProp_('LJ_MEETING_DATA_VERSION', next);
  SETTINGS_MAP_CACHE_ = null;
  return next;
}

function smallSheetCacheKey_(sheetName) {
  return 'SMALL_V130_' + String(sheetName) + '_' + dataVersion_();
}

function readSmallSheetCache_(sheetName) {
  try {
    const hit = CacheService.getScriptCache().get(smallSheetCacheKey_(sheetName));
    if (!hit) return null;
    const parsed = JSON.parse(hit);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch (err) { return null; }
}

function writeSmallSheetCache_(sheetName, payload) {
  try {
    const json = JSON.stringify(payload);
    if (json.length < 95000) {
      CacheService.getScriptCache().put(smallSheetCacheKey_(sheetName), json, SMALL_SHEET_CACHE_TTL_);
    }
  } catch (err) { /* 快取失敗不影響正確性 */ }
}

/** 系統資料夾網址存進 Script Properties，避免每次 bootstrap 都打 Drive。 */
function getRootFolderUrlCached_() {
  let url = prop_(PROP.ROOT_FOLDER_URL);
  if (!url) {
    url = getRootFolder_().getUrl();
    setProp_(PROP.ROOT_FOLDER_URL, url);
  }
  return url;
}

function trashIfExists_(fileId) {
  const id = String(fileId || '').trim();
  if (!id) return;
  try { DriveApp.getFileById(id).setTrashed(true); } catch (err) { /* 已刪除或無權限，忽略 */ }
}

/* --------------------------------------------------------------------------
 * 新功能：一鍵帶入上一場會議的內容
 * ------------------------------------------------------------------------ */

/**
 * 找出同一單位「上一場有內容的會議」，把可重用的區塊回傳給前端。
 * 只回傳資料，不直接寫入資料庫，由使用者確認後再自行儲存。
 * 圖片與附件綁定舊會議的 attachmentId，不能沿用，因此會被過濾掉。
 */
function copyPreviousReport(meetingId, unitId) {
  const user = requireUser_();
  const current = getMeetingInternal_(meetingId);
  assertUnitPermission_(user, unitId, getMeetingUnitDef_(current, unitId));
  const currentDate = parseDateOnly_(current.meetingDate).getTime();

  const earlier = listMeetingsInternal_()
    .filter(m => parseDateOnly_(m.meetingDate).getTime() < currentDate)
    .sort((a, b) => parseDateOnly_(b.meetingDate).getTime() - parseDateOnly_(a.meetingDate).getTime());

  const byMeeting = {};
  getObjectsByFieldValue_(SHEET.REPORTS, 'unitId', String(unitId))
    .forEach(r => byMeeting[String(r.meetingId)] = r);

  for (const m of earlier) {
    const r = byMeeting[String(m.meetingId)];
    if (!r) continue;
    const blocks = safeJsonParse_(r.contentJson, []);
    if (!Array.isArray(blocks) || !blocks.length) continue;
    const reusable = blocks.filter(b => b && ['section', 'text', 'link', 'table'].includes(String(b.type)));
    if (!reusable.length) continue;
    return {
      ok: true,
      fromMeetingId: String(m.meetingId),
      fromMeetingName: String(m.name || ''),
      fromMeetingDate: normalizeDateOnlyValue_(m.meetingDate),
      blocks: reusable,
      droppedAttachments: blocks.length - reusable.length
    };
  }
  return {ok: false, message: '找不到此單位先前的報告內容。'};
}

/* --------------------------------------------------------------------------
 * 新功能：管理員手動催繳
 * ------------------------------------------------------------------------ */

function sendManualReminder(meetingId) {
  const admin = requireAdmin_();
  const meeting = getMeetingInternal_(meetingId);
  const submitted = new Set(
    getMeetingReports_(meetingId)
      .filter(r => String(r.status) === 'SUBMITTED')
      .map(r => String(r.unitId))
  );
  const pending = getMeetingUnits_(meeting).filter(u => !submitted.has(u.id));
  if (!pending.length) return {ok: true, sent: 0, message: '所有單位都已正式送出，不需催繳。'};
  sendPendingReminder_(meeting, '（管理員手動提醒）');
  audit_('REMINDER_MANUAL', 'MEETING', meetingId, meetingId, '', admin.email, {pending: pending.map(u => u.id)});
  return {ok: true, sent: pending.length, pendingLabels: pending.map(u => u.label)};
}

/* --------------------------------------------------------------------------
 * 新功能：全份彙整預覽（產檔前先看一遍）
 * ------------------------------------------------------------------------ */

function getMeetingFullPreview(meetingId) {
  const user = requireUser_();
  const role = String(user.role || 'EDITOR').toUpperCase();
  if (!['ADMIN','DIRECTOR'].includes(role)) throw new Error('此功能僅限系統管理員或處室主任。');

  const meeting = getMeetingInternal_(meetingId);
  const meetingUnits = getMeetingUnits_(meeting);
  const visibleUnits = role === 'ADMIN'
    ? meetingUnits
    : meetingUnits.filter(u => userCanEditUnit_(user, u.id, u));

  const byUnit = {};
  getMeetingReports_(meetingId).forEach(r => byUnit[String(r.unitId)] = r);
  const visibleUnitIdSet = new Set(visibleUnits.map(u => String(u.id)));
  const attMap = {};
  getMeetingAttachments_(meetingId).filter(a =>
    String(a.active).toUpperCase() !== 'FALSE' &&
    visibleUnitIdSet.has(String(a.unitId))
  ).forEach(a => attMap[String(a.attachmentId)] = safeAttachment_(a));

  return {
    meeting: safeMeeting_(meeting),
    units: visibleUnits.map(u => {
      const r = byUnit[u.id];
      return {
        unitId: u.id, office: u.office, label: u.label, color: u.color,
        status: r ? String(r.status || 'DRAFT') : 'NOT_STARTED',
        noReport: r ? (String(r.noReport).toUpperCase() === 'TRUE' || r.noReport === true) : false,
        updatedAt: r ? String(r.updatedAt || '') : '',
        blocks: r ? safeJsonParse_(r.contentJson, []) : []
      };
    }),
    attachments: attMap
  };
}

/* --------------------------------------------------------------------------
 * 新功能：歷史版本檢視（ReportHistory 早就在存了，只是沒有介面）
 * ------------------------------------------------------------------------ */

function listReportHistory(meetingId, unitId) {
  const user = requireUser_();
  if (String(user.role).toUpperCase() !== 'ADMIN') {
    const meeting = getMeetingInternal_(meetingId);
    assertUnitPermission_(user, unitId, getMeetingUnitDef_(meeting, unitId));
  }
  return getObjectsByFieldValue_(SHEET.REPORT_HISTORY, 'meetingId', String(meetingId))
    .filter(h => String(h.unitId) === String(unitId))
    .sort((a, b) => Number(b.revision || 0) - Number(a.revision || 0))
    .slice(0, 30)
    .map(h => ({
      historyId: String(h.historyId || ''),
      revision: Number(h.revision || 0),
      status: String(h.status || ''),
      changedBy: String(h.changedBy || ''),
      changedAt: String(h.changedAt || ''),
      blocks: safeJsonParse_(h.contentJson, [])
    }));
}
